import { useEffect, useMemo, useState } from 'react';
import { motion } from 'framer-motion';
import type { LucideIcon } from 'lucide-react';
import {
  AudioWaveform, BellRing, Check, ChevronLeft, ChevronRight, Clapperboard, Copy,
  Download, HeartPulse, Layers, ListVideo, MonitorPlay, Target, User, Volume2, Wind, Zap,
} from 'lucide-react';
import type { TitleSrc } from '../engine/series';
import { buildSeries, partToText, seriesToText, PERSONA_LABEL } from '../engine/series';
import { cn } from '../utils/cn';

const SFX: Record<string, LucideIcon> = {
  drone: AudioWaveform, ding: BellRing, cut: Volume2, hit: Zap, pulse: HeartPulse, wind: Wind,
};

function CopyBtn({ text, label, big }: { text: string; label: string; big?: boolean }) {
  const [ok, setOk] = useState(false);
  const doCopy = async () => {
    try { await navigator.clipboard.writeText(text); } catch { /* noop */ }
    setOk(true); setTimeout(() => setOk(false), 1500);
  };
  return (
    <button
      onClick={doCopy}
      className={cn(
        'flex items-center gap-1.5 border font-mono uppercase tracking-widest transition-colors',
        big ? 'px-3.5 py-2 text-[11px]' : 'px-2.5 py-1.5 text-[10px]',
        ok ? 'border-[#CFFF3E] bg-[#CFFF3E] text-black' : 'border-white/15 text-white/55 hover:border-[#CFFF3E]/60 hover:text-[#CFFF3E]'
      )}
    >
      {ok ? <Check size={big ? 12 : 11} /> : <Copy size={big ? 12 : 11} />}
      {ok ? 'Copied' : label}
    </button>
  );
}

export default function SeriesPlayer({ title }: { title: TitleSrc | null }) {
  const [duration, setDuration] = useState(60);
  const [partIdx, setPartIdx] = useState(0);

  useEffect(() => { setPartIdx(0); }, [title?.id]);

  const pack = useMemo(() => (title ? buildSeries(title, duration) : null), [title, duration]);
  const part = pack?.parts[Math.min(partIdx, (pack?.parts.length ?? 1) - 1)];

  if (!title || !pack || !part) {
    return (
      <div className="flex min-h-[560px] flex-col items-center justify-center border border-dashed border-white/15 px-6 text-center">
        <MonitorPlay size={34} className="mb-4 text-white/20" />
        <p className="font-display text-2xl font-bold uppercase text-white/30">No title loaded</p>
        <p className="mt-2 max-w-sm font-mono text-[11px] leading-relaxed text-white/25">
          Left se koi title kholo — database se ya shelf se. Ya "New custom story" mein apna naam + plot save karke apni script banao.
        </p>
      </div>
    );
  }

  const total = pack.parts.length;
  const narrationText = part.paragraphs.join('\n\n');

  const downloadAll = () => {
    const blob = new Blob([seriesToText(pack)], { type: 'text/plain;charset=utf-8' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `${title.name.replace(/\s+/g, '_')}_series_script.txt`;
    a.click();
    URL.revokeObjectURL(a.href);
  };

  return (
    <motion.div key={title.id} initial={{ opacity: 0, y: 18 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.5 }} className="flex flex-col gap-8">
      {/* ── title header ── */}
      <header className="flex flex-col gap-5">
        <div className="flex items-center gap-3 font-mono text-[10px] uppercase tracking-[0.3em] text-[#CFFF3E]">
          <span className="h-px w-8 bg-[#CFFF3E]/60" />
          Series // {title.type} · MC-POV Hinglish
        </div>
        <h2 className="font-display text-[clamp(26px,3.6vw,46px)] font-extrabold leading-[0.95] tracking-tight text-white">
          {title.name}
        </h2>
        <div className="flex flex-wrap items-center gap-2">
          <span className="flex items-center gap-1.5 border border-white/12 bg-white/[0.03] px-2.5 py-1 font-mono text-[10px] tracking-wider text-white/55">
            <User size={10} className="text-[#CFFF3E]" /> {title.mc}
          </span>
          {[
            `${total} PARTS`,
            PERSONA_LABEL(title.persona).toUpperCase(),
            title.status === 'custom' ? 'CUSTOM · SAVED' : title.status.toUpperCase(),
          ].map((c) => (
            <span key={c} className="border border-white/12 bg-white/[0.03] px-2.5 py-1 font-mono text-[10px] tracking-wider text-white/55">{c}</span>
          ))}
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <div className="flex border border-white/15">
            {[45, 60].map((d) => (
              <button
                key={d}
                onClick={() => setDuration(d)}
                className={cn(
                  'h-[38px] px-4 font-mono text-[11px] font-bold transition-colors',
                  duration === d ? 'bg-[#CFFF3E] text-black' : 'text-white/50 hover:bg-white/10 hover:text-white'
                )}
              >
                {d}s
              </button>
            ))}
          </div>
          <CopyBtn big text={seriesToText(pack)} label={`Copy all ${total} parts`} />
          <button
            onClick={downloadAll}
            className="flex items-center gap-1.5 border border-white/15 px-3.5 py-2 font-mono text-[11px] uppercase tracking-widest text-white/55 transition-colors hover:border-[#CFFF3E]/60 hover:text-[#CFFF3E]"
          >
            <Download size={12} /> .txt
          </button>
        </div>
      </header>

      {/* ── part rail ── */}
      <div className="flex flex-col gap-3">
        <div className="flex items-center justify-between">
          <span className="font-mono text-[10px] uppercase tracking-[0.25em] text-white/40">
            Part {String(part.n).padStart(2, '0')} / {String(total).padStart(2, '0')}
          </span>
          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setPartIdx((p) => Math.max(0, p - 1))}
              disabled={partIdx === 0}
              className="flex h-8 w-8 items-center justify-center border border-white/15 text-white/60 transition-colors hover:border-[#CFFF3E] hover:text-[#CFFF3E] disabled:opacity-25 disabled:hover:border-white/15 disabled:hover:text-white/60"
            >
              <ChevronLeft size={14} />
            </button>
            <button
              onClick={() => setPartIdx((p) => Math.min(total - 1, p + 1))}
              disabled={partIdx === total - 1}
              className="flex h-8 w-8 items-center justify-center border border-white/15 text-white/60 transition-colors hover:border-[#CFFF3E] hover:text-[#CFFF3E] disabled:opacity-25 disabled:hover:border-white/15 disabled:hover:text-white/60"
            >
              <ChevronRight size={14} />
            </button>
          </div>
        </div>
        <div className="scroll-none -mx-1 flex gap-1.5 overflow-x-auto px-1 pb-1">
          {pack.parts.map((p, i) => (
            <button
              key={p.n}
              onClick={() => setPartIdx(i)}
              title={p.arc}
              className={cn(
                'shrink-0 border px-3.5 py-2.5 font-mono text-[12px] font-bold transition-all',
                i === partIdx
                  ? 'border-[#CFFF3E] bg-[#CFFF3E] text-black'
                  : i < partIdx
                    ? 'border-white/15 bg-white/[0.04] text-white/45 hover:border-white/35'
                    : 'border-white/10 text-white/60 hover:border-[#CFFF3E]/50 hover:text-white'
              )}
            >
              {String(p.n).padStart(2, '0')}
            </button>
          ))}
        </div>
      </div>

      {/* ── current part ── */}
      <motion.div
        key={`${title.id}-${part.n}-${duration}`}
        initial={{ opacity: 0, y: 14 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="flex flex-col gap-6"
      >
        {/* arc + why */}
        <div className="flex flex-col gap-3 border border-white/10 bg-gradient-to-br from-white/[0.04] to-transparent p-5">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <h3 className="font-display text-lg font-bold text-white sm:text-xl">
              <span className="text-[#CFFF3E]">P{String(part.n).padStart(2, '0')}</span> — {part.arc}
            </h3>
            <CopyBtn text={partToText(title, part)} label="Copy part" />
          </div>
          <p className="flex items-start gap-2.5 border-l-2 border-[#FF4D2E] pl-3 text-[12.5px] italic leading-relaxed text-white/50">
            <Target size={13} className="mt-0.5 shrink-0 text-[#FF4D2E]" />
            {part.hookWhy}
          </p>
        </div>

        {/* narration */}
        <div className="relative border border-white/10 bg-[#101014]">
          <div className="pointer-events-none absolute inset-y-0 left-0 w-1 bg-gradient-to-b from-[#CFFF3E] via-[#CFFF3E]/25 to-transparent" />
          <div className="flex items-center justify-between border-b border-white/10 px-5 py-3 sm:px-7">
            <span className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.25em] text-white/40">
              <Clapperboard size={12} className="text-[#CFFF3E]" /> Narration — {title.mc} (1st person)
            </span>
            <span className="font-mono text-[10px] text-[#CFFF3E]">≈{part.words} words · {part.estMin}–{part.estMax}s</span>
          </div>
          <div className="flex flex-col gap-5 p-5 sm:p-7">
            {part.paragraphs.map((t, i) => (
              <div key={i} className="group flex gap-4">
                <span className="mt-1 shrink-0 font-mono text-[10px] text-white/20 transition-colors group-hover:text-[#CFFF3E]">
                  P{i + 1}
                </span>
                <p className="text-[15px] leading-[1.8] text-white/85">
                  {t}
                  {i === part.paragraphs.length - 1 && part.nextTease && (
                    <span className="ml-2 inline-block -translate-y-px border border-[#FF4D2E]/40 bg-[#FF4D2E]/10 px-1.5 py-[1px] align-middle font-mono text-[9px] uppercase tracking-widest text-[#FF7A5C]">
                      CTA
                    </span>
                  )}
                </p>
              </div>
            ))}
          </div>
          <div className="flex items-center justify-between border-t border-white/10 px-5 py-3 font-mono text-[10px] text-white/30 sm:px-7">
            <span>VOICE: HINGLISH · TONE: {PERSONA_LABEL(title.persona).toUpperCase()}</span>
            <CopyBtn text={narrationText} label="Copy narration" />
          </div>
        </div>

        {/* edit beats + sound */}
        <div className="grid gap-6 xl:grid-cols-[1.35fr_1fr]">
          <div>
            <div className="mb-3 flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.25em] text-white/40">
              <ListVideo size={12} className="text-[#CFFF3E]" /> Edit beats — {part.scenes.length} cuts
            </div>
            <div className="flex flex-col">
              {part.scenes.map((s, i) => (
                <div key={i} className="group relative grid grid-cols-[64px_1fr] gap-3 border-l border-white/12 pb-4 last:pb-0">
                  <div className="relative pt-0.5 text-right">
                    <span className="absolute -left-[4px] top-1.5 h-[7px] w-[7px] rounded-full bg-[#0B0B0D] ring-2 ring-[#CFFF3E] transition-colors group-hover:bg-[#CFFF3E]" />
                    <span className="mr-1.5 inline-block font-mono text-[10px] font-bold text-[#CFFF3E]">{s.from}–{s.to}s</span>
                  </div>
                  <div className="border border-white/10 bg-white/[0.02] p-3 transition-colors group-hover:border-white/25">
                    <p className="font-mono text-[10.5px] italic text-[#FF7A5C]">“{s.line}”</p>
                    <p className="mt-1 text-[12px] leading-snug text-white/65">{s.visual}</p>
                    <div className="mt-2 flex flex-wrap gap-1">
                      {s.fx.map((f) => (
                        <span key={f} className="border border-[#CFFF3E]/25 bg-[#CFFF3E]/[0.05] px-1.5 py-px font-mono text-[8.5px] uppercase tracking-wider text-[#CFFF3E]/80">
                          {f}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
          <div>
            <div className="mb-3 flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.25em] text-white/40">
              <AudioWaveform size={12} className="text-[#CFFF3E]" /> Sound design
            </div>
            <div className="flex flex-col gap-2">
              {part.sound.map((s, i) => {
                const Icon = SFX[s.icon] ?? AudioWaveform;
                return (
                  <div key={i} className="flex items-start gap-3 border border-white/10 bg-white/[0.02] p-3.5 transition-colors hover:border-[#CFFF3E]/40">
                    <div className="flex h-8 w-8 shrink-0 items-center justify-center bg-[#CFFF3E] text-black">
                      <Icon size={14} strokeWidth={2.2} />
                    </div>
                    <div>
                      <p className="text-[12px] font-bold uppercase tracking-wide text-white">{s.label}</p>
                      <p className="mt-0.5 text-[11px] leading-relaxed text-white/50">{s.desc}</p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* next tease */}
        {part.nextTease ? (
          <button
            onClick={() => setPartIdx((p) => Math.min(total - 1, p + 1))}
            className="group flex items-center justify-between border border-[#CFFF3E]/30 bg-[#CFFF3E]/[0.05] px-5 py-4 text-left transition-colors hover:bg-[#CFFF3E]/[0.1]"
          >
            <span className="font-mono text-[11px] uppercase tracking-[0.2em] text-white/60">
              Up next <span className="text-[#CFFF3E]">// P{String(part.n + 1).padStart(2, '0')} — {part.nextTease}</span>
            </span>
            <ChevronRight size={16} className="text-[#CFFF3E] transition-transform group-hover:translate-x-1.5" />
          </button>
        ) : (
          <div className="flex items-center justify-between border border-white/10 bg-white/[0.03] px-5 py-4">
            <span className="font-mono text-[11px] uppercase tracking-[0.2em] text-white/40">
              Series complete — <span className="text-white/70">poori script copy karke record karo</span>
            </span>
            <Layers size={15} className="text-[#CFFF3E]" />
          </div>
        )}
      </motion.div>
    </motion.div>
  );
}
