import { useEffect, useMemo, useState, type ReactNode } from 'react';
import {
  Bookmark, BookmarkCheck, BookMarked, Database, Flame, Library as LibraryIcon,
  PenLine, Plus, Search, Star, Trash2, X,
} from 'lucide-react';
import { GENRE_LIST, type GenreKey } from '../engine/generator';
import type { MediaType, TitleSrc } from '../engine/series';
import { buildCustomTitle, customFromSerialized, PERSONA_LABEL } from '../engine/series';
import { TITLES_A } from '../data/titlesA';
import { TITLES_B } from '../data/titlesB';
import { TITLES_C } from '../data/titlesC';
import { cn } from '../utils/cn';

export const ALL_TITLES: TitleSrc[] = [...TITLES_A, ...TITLES_B, ...TITLES_C];

// ── persistence ──
const LS_CUSTOM = 'hookframe.customs.v1';
const LS_SAVED = 'hookframe.saved.v1';

interface SerializedCustom {
  uid: string; name: string; type: MediaType; genre: GenreKey; mc: string; plot: string;
}

function loadLS<T>(k: string, fb: T): T {
  try { const v = localStorage.getItem(k); return v ? (JSON.parse(v) as T) : fb; } catch { return fb; }
}
function saveLS(k: string, v: unknown) {
  try { localStorage.setItem(k, JSON.stringify(v)); } catch { /* private mode */ }
}

const TYPE_COLOR: Record<MediaType, string> = {
  MANHWA: 'text-[#CFFF3E] border-[#CFFF3E]/40 bg-[#CFFF3E]/[0.06]',
  ANIME: 'text-[#FF7A5C] border-[#FF4D2E]/40 bg-[#FF4D2E]/[0.06]',
  DONGHUA: 'text-[#6EE7F9] border-[#6EE7F9]/40 bg-[#6EE7F9]/[0.06]',
  MANGA: 'text-white/70 border-white/20 bg-white/[0.05]',
  NOVEL: 'text-white/70 border-white/20 bg-white/[0.05]',
  CUSTOM: 'text-white/70 border-white/20 bg-white/[0.05]',
};

function Label({ n, children }: { n: string; children: ReactNode }) {
  return (
    <div className="flex items-baseline gap-2">
      <span className="font-mono text-[10px] text-[#CFFF3E]">{n}</span>
      <span className="font-mono text-[10px] uppercase tracking-[0.25em] text-white/40">{children}</span>
    </div>
  );
}

interface Props {
  onOpen: (t: TitleSrc) => void;
  activeId: string | null;
}

export default function Library({ onOpen, activeId }: Props) {
  const [q, setQ] = useState('');
  const [savedIds, setSavedIds] = useState<string[]>(() => loadLS(LS_SAVED, ['orv']));
  const [customs, setCustoms] = useState<SerializedCustom[]>(() => loadLS(LS_CUSTOM, []));
  const [formOpen, setFormOpen] = useState(false);
  // custom form fields
  const [fName, setFName] = useState('');
  const [fType, setFType] = useState<MediaType>('MANHWA');
  const [fGenre, setFGenre] = useState<GenreKey>('apocalypse');
  const [fMc, setFMc] = useState('');
  const [fPlot, setFPlot] = useState('');

  useEffect(() => saveLS(LS_SAVED, savedIds), [savedIds]);
  useEffect(() => saveLS(LS_CUSTOM, customs), [customs]);

  const results = useMemo(() => {
    const s = q.trim().toLowerCase();
    if (!s) return ALL_TITLES;
    return ALL_TITLES.filter(
      (t) =>
        t.name.toLowerCase().includes(s) ||
        t.mc.toLowerCase().includes(s) ||
        (t.aka ?? []).some((a) => a.toLowerCase().includes(s))
    );
  }, [q]);

  const exactMatch = q.trim().length > 1 && results.some((t) => t.name.toLowerCase() === q.trim().toLowerCase());

  const shelfTitles = useMemo(() => {
    const list: TitleSrc[] = [];
    customs.forEach((c) => { const t = customFromSerialized(c); if (t.parts.length) list.push(t); });
    savedIds.forEach((id) => { const t = ALL_TITLES.find((x) => x.id === id); if (t) list.push(t); });
    return list;
  }, [customs, savedIds]);

  const toggleSave = (id: string) =>
    setSavedIds((p) => (p.includes(id) ? p.filter((x) => x !== id) : [...p, id]));

  const addCustom = () => {
    if (!fName.trim() || fPlot.trim().length < 40) return;
    const uid = Date.now().toString(36);
    const rec: SerializedCustom = {
      uid,
      name: fName.trim(),
      type: fType,
      genre: fGenre,
      mc: fMc.trim(),
      plot: fPlot.trim(),
    };
    setCustoms((p) => [rec, ...p.filter((x) => x.name.toLowerCase() !== rec.name.toLowerCase())]);
    const t = buildCustomTitle(rec);
    setFormOpen(false);
    setFPlot(''); setFName(''); setFMc('');
    onOpen(t);
  };

  const plotOk = fPlot.trim().length >= 40;

  return (
    <div className="flex flex-col gap-7">
      {/* ── search ── */}
      <section className="flex flex-col gap-3">
        <Label n="S1">Kisi bhi title ka naam daalo</Label>
        <div className="relative">
          <Search size={15} className="pointer-events-none absolute left-3.5 top-1/2 -translate-y-1/2 text-white/30" />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="anime / manhwa / donghua ka naam…"
            className="w-full border border-white/10 bg-white/[0.03] py-3.5 pl-10 pr-10 text-[14px] text-white placeholder:text-white/25 outline-none transition-colors focus:border-[#CFFF3E]/60 focus:bg-[#CFFF3E]/[0.03]"
          />
          {q && (
            <button onClick={() => setQ('')} className="absolute right-3 top-1/2 -translate-y-1/2 text-white/30 hover:text-white">
              <X size={14} />
            </button>
          )}
        </div>
        {q.trim().length > 1 && !exactMatch && (
          <button
            onClick={() => { setFName(q.trim()); setFormOpen(true); }}
            className="flex items-center justify-between border border-dashed border-[#CFFF3E]/40 bg-[#CFFF3E]/[0.04] px-3.5 py-3 text-left transition-colors hover:bg-[#CFFF3E]/[0.08]"
          >
            <span className="text-[12px] text-white/75">
              <span className="text-[#CFFF3E]">“{q.trim()}”</span> database mein nahi hai — custom story banao
            </span>
            <Plus size={14} className="shrink-0 text-[#CFFF3E]" />
          </button>
        )}
      </section>

      {/* ── my shelf ── */}
      <section className="flex flex-col gap-3">
        <Label n="S2">My shelf — saved</Label>
        {shelfTitles.length === 0 ? (
          <div className="border border-dashed border-white/12 px-4 py-6 text-center">
            <BookMarked size={18} className="mx-auto mb-2 text-white/20" />
            <p className="font-mono text-[11px] text-white/30">
              Shelf khali hai — database se <Bookmark size={10} className="inline text-[#CFFF3E]" /> dabao ya custom story save karo.
            </p>
          </div>
        ) : (
          <div className="flex flex-col gap-1.5">
            {shelfTitles.map((t) => {
              const isCustom = t.status === 'custom';
              return (
                <div
                  key={t.id}
                  className={cn(
                    'group flex items-center gap-3 border px-3 py-2.5 transition-colors',
                    activeId === t.id ? 'border-[#CFFF3E]/60 bg-[#CFFF3E]/[0.05]' : 'border-white/10 bg-white/[0.02] hover:border-white/25'
                  )}
                >
                  <Star size={12} className={cn('shrink-0', isCustom ? 'text-[#6EE7F9]' : 'text-[#CFFF3E]')} fill="currentColor" />
                  <button onClick={() => onOpen(t)} className="min-w-0 flex-1 text-left">
                    <span className={cn('block truncate text-[13px] font-semibold', activeId === t.id ? 'text-[#CFFF3E]' : 'text-white/85')}>
                      {t.name}
                    </span>
                    <span className="block truncate font-mono text-[10px] text-white/30">
                      {t.parts.length} parts · {isCustom ? 'custom' : t.type.toLowerCase()} · MC: {t.mc}
                    </span>
                  </button>
                  {isCustom ? (
                    <button
                      onClick={() => setCustoms((p) => p.filter((x) => 'custom_' + x.uid !== t.id))}
                      className="text-white/25 transition-colors hover:text-[#FF4D2E]"
                      title="Delete custom"
                    >
                      <Trash2 size={13} />
                    </button>
                  ) : (
                    <button
                      onClick={() => toggleSave(t.id)}
                      className="text-white/25 transition-colors hover:text-[#FF4D2E]"
                      title="Remove from shelf"
                    >
                      <X size={13} />
                    </button>
                  )}
                </div>
              );
            })}
          </div>
        )}
      </section>

      {/* ── custom form ── */}
      <section className="flex flex-col gap-3">
        <button
          onClick={() => setFormOpen((v) => !v)}
          className={cn(
            'flex items-center justify-between border px-3.5 py-3 transition-colors',
            formOpen ? 'border-[#CFFF3E]/60 bg-[#CFFF3E]/[0.05]' : 'border-white/10 bg-white/[0.02] hover:border-white/25'
          )}
        >
          <span className="flex items-center gap-2 text-[12px] font-bold uppercase tracking-wider text-white/80">
            <PenLine size={13} className="text-[#CFFF3E]" /> New custom story save karo
          </span>
          <Plus size={14} className={cn('text-white/40 transition-transform', formOpen && 'rotate-45 text-[#CFFF3E]')} />
        </button>

        {formOpen && (
          <div className="flex flex-col gap-3 border border-white/10 bg-white/[0.02] p-4">
            <input
              value={fName}
              onChange={(e) => setFName(e.target.value)}
              placeholder="Title ka naam *"
              className="border border-white/10 bg-[#0B0B0D] px-3 py-2.5 text-[13px] text-white placeholder:text-white/25 outline-none focus:border-[#CFFF3E]/60"
            />
            <div className="grid grid-cols-2 gap-2">
              <select
                value={fType}
                onChange={(e) => setFType(e.target.value as MediaType)}
                className="border border-white/10 bg-[#0B0B0D] px-3 py-2.5 font-mono text-[11px] text-white/70 outline-none focus:border-[#CFFF3E]/60"
              >
                {(['MANHWA', 'ANIME', 'DONGHUA', 'MANGA', 'NOVEL'] as MediaType[]).map((t) => (
                  <option key={t} value={t}>{t}</option>
                ))}
              </select>
              <select
                value={fGenre}
                onChange={(e) => setFGenre(e.target.value as GenreKey)}
                className="border border-white/10 bg-[#0B0B0D] px-3 py-2.5 font-mono text-[11px] text-white/70 outline-none focus:border-[#CFFF3E]/60"
              >
                {GENRE_LIST.map((g) => (
                  <option key={g.key} value={g.key}>{g.label}</option>
                ))}
              </select>
            </div>
            <input
              value={fMc}
              onChange={(e) => setFMc(e.target.value)}
              placeholder="Main character ka naam (POV voice)"
              className="border border-white/10 bg-[#0B0B0D] px-3 py-2.5 text-[13px] text-white placeholder:text-white/25 outline-none focus:border-[#CFFF3E]/60"
            />
            <textarea
              value={fPlot}
              onChange={(e) => setFPlot(e.target.value)}
              rows={5}
              placeholder="Poori kahani 6-12 sentences mein likho ya paste karo — engine isse Part 1..N mein tod dega (min 40 chars)…"
              className="resize-none border border-white/10 bg-[#0B0B0D] px-3 py-2.5 text-[13px] leading-relaxed text-white placeholder:text-white/25 outline-none focus:border-[#CFFF3E]/60"
            />
            <button
              onClick={addCustom}
              disabled={!fName.trim() || !plotOk}
              className={cn(
                'flex h-11 items-center justify-center gap-2 text-[12px] font-black uppercase tracking-[0.15em] transition-all',
                fName.trim() && plotOk
                  ? 'bg-[#CFFF3E] text-black active:scale-[0.98]'
                  : 'cursor-not-allowed bg-white/[0.06] text-white/25'
              )}
            >
              <Plus size={14} /> Save + generate series
            </button>
            <p className="font-mono text-[10px] leading-relaxed text-white/30">
              Genre se MC ka persona auto-set hota hai — narration usi voice mein likha jaayega. Shelf mein saved rehta hai.
            </p>
          </div>
        )}
      </section>

      <div className="h-px bg-white/[0.07]" />

      {/* ── database ── */}
      <section className="flex flex-col gap-3">
        <div className="flex items-baseline justify-between">
          <Label n="DB">Built-in database</Label>
          <span className="flex items-center gap-1.5 font-mono text-[10px] text-white/30">
            <Database size={11} className="text-[#CFFF3E]" /> {results.length}/{ALL_TITLES.length}
          </span>
        </div>
        <div className="flex flex-col gap-2">
          {results.map((t) => {
            const saved = savedIds.includes(t.id);
            return (
              <div
                key={t.id}
                className={cn(
                  'group flex items-start gap-3 border p-3.5 transition-all',
                  activeId === t.id
                    ? 'border-[#CFFF3E]/60 bg-[#CFFF3E]/[0.05]'
                    : 'border-white/10 bg-white/[0.02] hover:border-white/25 hover:bg-white/[0.04]'
                )}
              >
                <button onClick={() => onOpen(t)} className="min-w-0 flex-1 text-left">
                  <span className="flex flex-wrap items-center gap-x-2 gap-y-1">
                    <span className={cn('text-[13.5px] font-bold leading-tight', activeId === t.id ? 'text-[#CFFF3E]' : 'text-white/90')}>
                      {t.name}
                    </span>
                    <span className={cn('border px-1.5 py-[1px] font-mono text-[8.5px] uppercase tracking-widest', TYPE_COLOR[t.type])}>
                      {t.type}
                    </span>
                    {t.status === 'ongoing' && (
                      <span className="flex items-center gap-1 font-mono text-[8.5px] uppercase tracking-widest text-[#FF7A5C]">
                        <Flame size={9} /> ongoing
                      </span>
                    )}
                  </span>
                  <span className="mt-1 block truncate font-mono text-[10px] text-white/35">
                    MC: {t.mc} · {t.parts.length} parts · {PERSONA_LABEL(t.persona)}
                  </span>
                </button>
                <button
                  onClick={() => toggleSave(t.id)}
                  title={saved ? 'Remove from shelf' : 'Save to shelf'}
                  className={cn('mt-0.5 shrink-0 transition-colors', saved ? 'text-[#CFFF3E]' : 'text-white/25 hover:text-[#CFFF3E]')}
                >
                  {saved ? <BookmarkCheck size={15} /> : <Bookmark size={15} />}
                </button>
              </div>
            );
          })}
          {results.length === 0 && (
            <div className="border border-dashed border-white/12 px-4 py-8 text-center">
              <LibraryIcon size={18} className="mx-auto mb-2 text-white/20" />
              <p className="font-mono text-[11px] text-white/30">Koi match nahi — upar se custom story save karo, turant parts mil jaayenge.</p>
            </div>
          )}
        </div>
      </section>
    </div>
  );
}
