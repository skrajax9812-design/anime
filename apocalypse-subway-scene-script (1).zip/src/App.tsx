import { useEffect, useRef, useState } from 'react';
import { motion } from 'framer-motion';
import { ArrowDown, BookOpenText, Clapperboard } from 'lucide-react';
import type { TitleSrc } from './engine/series';
import Library, { ALL_TITLES } from './components/Library';
import SeriesPlayer from './components/SeriesPlayer';
import { cn } from './utils/cn';

// ── live studio timecode ──
function Timecode() {
  const start = useRef(Date.now());
  const [, force] = useState(0);
  useEffect(() => {
    const id = setInterval(() => force((x) => x + 1), 84);
    return () => clearInterval(id);
  }, []);
  const el = Date.now() - start.current;
  const p = (n: number) => String(n).padStart(2, '0');
  const h = Math.floor(el / 3600000) % 24;
  const m = Math.floor(el / 60000) % 60;
  const s = Math.floor(el / 1000) % 60;
  const f = Math.floor((el % 1000) / 1000 * 24);
  return (
    <span className="hidden font-mono text-[11px] tracking-[0.2em] text-white/40 md:block">
      TC {p(h)}:{p(m)}:{p(s)}:{p(f)}
    </span>
  );
}

const MARQUEE = ['ANIME', 'MANHWA', 'DONGHUA', 'MANGA', 'MC-POV', 'NARRATION', '45s / 60s', 'CLIFFHANGER'];

export default function App() {
  const [title, setTitle] = useState<TitleSrc | null>(null);

  // flagship ORV on first paint
  useEffect(() => {
    setTitle(ALL_TITLES.find((t) => t.id === 'orv') ?? ALL_TITLES[0]);
  }, []);

  return (
    <div className="min-h-screen bg-[#0B0B0D] font-body text-white antialiased">
      <div className="noise pointer-events-none fixed inset-0 z-[60]" />
      <div className="pointer-events-none fixed -left-40 top-[-10%] h-[480px] w-[480px] rounded-full bg-[#CFFF3E]/[0.05] blur-[140px]" />
      <div className="pointer-events-none fixed -right-40 bottom-[-10%] h-[480px] w-[480px] rounded-full bg-[#FF4D2E]/[0.06] blur-[140px]" />

      {/* ── header ── */}
      <header className="fixed inset-x-0 top-0 z-40 border-b border-white/[0.07] bg-[#0B0B0D]/85 backdrop-blur-md">
        <div className="mx-auto flex h-14 max-w-[1440px] items-center justify-between px-4 sm:px-8">
          <div className="flex items-center gap-3">
            <div className="flex h-7 w-7 items-center justify-center bg-[#CFFF3E] text-black">
              <Clapperboard size={15} strokeWidth={2.5} />
            </div>
            <span className="font-display text-[15px] font-extrabold uppercase tracking-wide">
              HookFrame<span className="text-[#CFFF3E]">.</span>
            </span>
            <span className="mt-0.5 hidden font-mono text-[9px] uppercase tracking-[0.3em] text-white/35 sm:block">
              Series script studio
            </span>
          </div>
          <div className="flex items-center gap-5">
            <Timecode />
            <span className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.25em] text-white/50">
              <span className="rec-dot h-2 w-2 rounded-full bg-[#FF4D2E]" />
              Rec
            </span>
          </div>
        </div>
      </header>

      {/* ── hero ── */}
      <section className="relative overflow-hidden px-4 pt-28 sm:px-8 sm:pt-32">
        <div className="mx-auto max-w-[1440px]">
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7 }}>
            <p className="flex items-center gap-3 font-mono text-[10px] uppercase tracking-[0.35em] text-[#CFFF3E] sm:text-[11px]">
              <span className="h-px w-10 bg-[#CFFF3E]/70" />
              Anime · Manhwa · Donghua — series script engine
            </p>
            <h1 className="mt-6 font-display font-extrabold uppercase leading-[0.9] tracking-tight">
              <span className="block text-[clamp(40px,8.5vw,118px)] text-white">Naam daalo.</span>
              <span className="block text-[clamp(40px,8.5vw,118px)]">
                <span className="text-stroke">Poori series</span> <span className="text-[#CFFF3E]">nikalo.</span>
              </span>
            </h1>
            <div className="mt-8 flex flex-col gap-6 sm:flex-row sm:items-end sm:justify-between">
              <p className="max-w-xl text-[15px] leading-relaxed text-white/55">
                Kisi bhi anime ya manhwa ka naam save karo — <span className="text-white">Part 1 se lekar end tak</span>,
                har episode-ready narration <span className="text-[#CFFF3E]">main character ki apni awaaz mein</span>.
                45s ya 60s, edit beats, sound design — sab camera-ready. Custom story? Wo bhi, shelf mein saved.
              </p>
              <a
                href="#studio"
                className="group inline-flex w-fit items-center gap-3 border border-white/15 px-5 py-3 font-mono text-[11px] uppercase tracking-[0.25em] text-white/70 transition-colors hover:border-[#CFFF3E] hover:text-[#CFFF3E]"
              >
                Open studio
                <ArrowDown size={14} className="transition-transform group-hover:translate-y-1" />
              </a>
            </div>

            <div className="mt-12 grid grid-cols-2 gap-px border border-white/10 bg-white/10 sm:grid-cols-4">
              {[
                ['21', 'titles in database'],
                ['90+', 'pre-written parts'],
                ['45/60s', 'per-part timing'],
                ['1st', 'person mc voice'],
              ].map(([v, k], i) => (
                <div key={k} className={cn('bg-[#0B0B0D] px-5 py-4', i === 3 && 'bg-[#CFFF3E]/[0.04]')}>
                  <p className={cn('font-display text-2xl font-extrabold', i === 3 ? 'text-[#CFFF3E]' : 'text-white')}>{v}</p>
                  <p className="mt-1 font-mono text-[9px] uppercase tracking-[0.25em] text-white/40">{k}</p>
                </div>
              ))}
            </div>
          </motion.div>
        </div>

        <div className="mt-14 border-y border-white/[0.08] py-3">
          <div className="marquee flex w-max gap-8 whitespace-nowrap">
            {[...MARQUEE, ...MARQUEE, ...MARQUEE].map((w, i) => (
              <span key={i} className="flex items-center gap-8 font-display text-[13px] font-bold uppercase tracking-[0.3em] text-white/30">
                {w} <BookOpenText size={12} className="text-[#CFFF3E]/60" />
              </span>
            ))}
          </div>
        </div>
      </section>

      {/* ── studio ── */}
      <section id="studio" className="scroll-mt-20 px-4 py-14 sm:px-8">
        <div className="mx-auto grid max-w-[1440px] gap-10 lg:grid-cols-[400px_minmax(0,1fr)] lg:gap-12">
          <div className="lg:sticky lg:top-20 lg:self-start">
            <div className="mb-6 flex items-center gap-3">
              <span className="font-display text-[13px] font-extrabold uppercase tracking-[0.2em] text-white">Library</span>
              <span className="h-px flex-1 bg-white/10" />
              <span className="font-mono text-[9px] uppercase tracking-[0.25em] text-white/30">Search · Save · Shelf</span>
            </div>
            <Library onOpen={setTitle} activeId={title?.id ?? null} />
          </div>

          <div className="min-w-0">
            <div className="mb-6 flex items-center gap-3">
              <span className="font-display text-[13px] font-extrabold uppercase tracking-[0.2em] text-white">Script monitor</span>
              <span className="h-px flex-1 bg-white/10" />
              <span className="font-mono text-[9px] uppercase tracking-[0.25em] text-white/30">Part-by-part narration</span>
            </div>
            <SeriesPlayer title={title} />
          </div>
        </div>
      </section>

      {/* ── footer ── */}
      <footer className="border-t border-white/[0.08] px-4 py-8 sm:px-8">
        <div className="mx-auto flex max-w-[1440px] flex-wrap items-center justify-between gap-3 font-mono text-[10px] uppercase tracking-[0.25em] text-white/35">
          <span>HookFrame Studio — built for recap creators</span>
          <span className="text-[#CFFF3E]">Part 2 mein milte hain.</span>
        </div>
      </footer>
    </div>
  );
}
