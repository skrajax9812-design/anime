// ─────────────────────────────────────────────────────────────
//  HOOKFRAME — Shorts Script Engine
//  Turns a story input into a full script pack:
//  cold open → narration → scene table → sound → roadmap
// ─────────────────────────────────────────────────────────────

export type Lang = 'hinglish' | 'english';
export type Tone = 'pov' | 'dramatic';
export type GenreKey =
  | 'apocalypse' | 'system' | 'regression' | 'fantasy'
  | 'horror' | 'romance' | 'action' | 'scifi';

export interface ScriptInput {
  title: string;
  genre: GenreKey;
  scene: string;
  part: number;
  duration: number; // seconds
  lang: Lang;
  tone: Tone;
}

export interface SceneRow { from: number; to: number; line: string; visual: string; fx: string[]; }
export interface SoundNote { icon: string; label: string; desc: string; }
export interface RoadPart { part: number; title: string; desc: string; }

export interface ScriptPack {
  id: number;
  input: ScriptInput;
  genreTag: string;
  coldOpen: { title: string; reasons: string[]; summary: string };
  narration: { paragraphs: string[]; words: number; estMin: number; estMax: number };
  scenes: SceneRow[];
  sound: SoundNote[];
  road: RoadPart[];
  rule: string;
}

// ── helpers ──────────────────────────────────────────────────

export function countWords(t: string): number {
  return t.trim().split(/\s+/).filter(Boolean).length;
}

function splitSentences(t: string): string[] {
  return t
    .split(/(?<=[.!?…।])\s+/)
    .map((s) => s.trim())
    .filter((s) => s.length > 1);
}

const pick = <T,>(arr: T[], i: number): T => arr[Math.abs(i) % arr.length];

function rep(s: string, inp: ScriptInput): string {
  return s
    .replace(/\{title\}/g, inp.title.trim() || 'Ek Kahani')
    .replace(/\{n1\}/g, String(inp.part + 1))
    .replace(/\{dur\}/g, String(inp.duration));
}

function excerpt(t: string, n = 9): string {
  const w = t.trim().split(/\s+/);
  return w.length > n ? w.slice(0, n).join(' ') + ' …' : t;
}

// ── genre template bank ──────────────────────────────────────

interface Visual { visual: string; fx: string[]; }
interface GenreBank {
  tag: string;
  cold: string;
  reasons: string[];
  defaultScene: string;
  hook: string[];
  setup: string[];
  turn: string[];
  sysIntro?: string[];
  systemLine?: string;
  escalate: string[];
  realize: string[];
  resolve: string[];
  cta: string[];
  filler: string[];
  visuals: Visual[];
  sounds: SoundNote[];
  road: { title: string; desc: string }[];
  rule: string;
}

const HI: Record<GenreKey, GenreBank> = {
  apocalypse: {
    tag: 'duniya khatam, scenario shuru',
    cold: 'Chapter 1 — "{title}" ka trigger moment',
    reasons: [
      'Relatable hook — ek aam insaan, bilkul aam se din mein phansa hua',
      'Turant twist — duniya aankhon ke saamne ek scenario mein badal jaati hai',
      'Character ka intro natural tareeke se hota hai — bina kisi info-dump ke',
      '60 sec mein self-contained "WTF just happened" moment — perfect Short hook',
    ],
    defaultScene:
      'Subway mein baitha tha main, jaise roz baitha karta tha. Tabhi ek awaaz — jo kisi insaan ki nahi thi — poori duniya mein gunji. Log chillane lage aur kuch aisa dikhne laga jo insaan nahi tha.',
    hook: [
      "Das saal. Das saal se main ek hi kahani ke peeche tha — '{title}'. Sabne beech mein chhod diya, boring keh ke. Sirf main tha jo isse aakhri tak le gaya.",
      "Jis din duniya badli, main apni roz ki routine mein tha. Bilkul aam aadmi, aam din. Bas ek cheez alag thi — '{title}' mere liye sirf ek kahani nahi thi.",
    ],
    setup: [
      'Wahi roz ki routine. Wahi bheed, wahi thakaan, wahi khidki ke bahar bhaagti hui duniya.',
      'Us din bhi sab waisa hi tha jaisa hamesha hota tha. Ek bilkul aam shaam — aakhri aam shaam.',
    ],
    turn: [
      'Aur tabhi... kuch aisa hua jiska andaaza mujhe sapne mein bhi nahi tha.',
      'Aur tabhi — duniya ka asli scene shuru ho gaya.',
    ],
    sysIntro: [
      'Ek awaaz gunji — aisi awaaz jo kisi insaan ki ho hi nahi sakti:',
      'Poori duniya mein ek hi message goonj utha:',
    ],
    systemLine: 'Pehla scenario shuru ho chuka hai.',
    escalate: [
      'Log chillane lage. Panic mein sab idhar-udhar bhaagne lage. Meri saans ruk si gayi — par dimaag tez chal raha tha.',
      'Chaar taraf sirf cheekhein thi. Kaanch toota, lights bujhi, aur bheed jaan bachane ke liye takraane lagi.',
    ],
    realize: [
      'Yeh sirf koi kahani nahi thi. Yeh meri duniya ki nayi sacchai ban rahi thi.',
      'Jo maine padha tha, jo sirf imagination thi — woh ab mere saamne, zinda khadi thi.',
    ],
    resolve: [
      'Aur sabse dukh wali baat? Sirf mujhe pata tha aage kya hone wala hai.',
      'Lekin ek baat sirf main jaanta tha — is kahani ka agla panne pe kya likha hai.',
    ],
    cta: [
      'Part {n1} mein bataunga main kaise bacha — follow karke rehna, kyunki yeh sirf shuruaat thi.',
      'Agle part mein — pehla scenario, pehla khoon. Dekhne ki himmat hai to follow kar lo.',
    ],
    filler: [
      'Dil ki dhadkan kaan mein gunj rahi thi. Haath kaanp rahe the, par dimaag ekdum shaant tha.',
    ],
    visuals: [
      { visual: 'Subway seat pe aadmi phone/book padhta hua — manhwa panel / AI art', fx: ['slow push-in', 'film grain'] },
      { visual: 'Book/screen band karta close-up, aankhein upar uthti hain', fx: ['match cut', 'soft vignette'] },
      { visual: 'Subway interior wide shot — lights flicker, dark eerie grade', fx: ['light flicker', 'cold color grade'] },
      { visual: 'System message text-on-screen — glitch reveal, red accent', fx: ['red flash', 'glitch text', 'screen shake'] },
      { visual: 'Panic scene — bhaagte log, door pe creature ka silhouette', fx: ['sudden silence', 'whip pan'] },
      { visual: 'Protagonist close-up — serious, determined expression', fx: ['heartbeat sync', 'tight crop'] },
      { visual: 'End card — "Part {n1} coming" text overlay', fx: ['subscribe pop', 'bass hit'] },
    ],
    sounds: [
      { icon: 'drone', label: 'Suspense drone', desc: 'Low rumble drone start se — tension floor banao.' },
      { icon: 'ding', label: 'System "ding"', desc: 'Glitch ding jab system line boli jaaye.' },
      { icon: 'cut', label: 'Silence cut', desc: 'Panic scene pe sudden silence, phir tension music peak pe.' },
      { icon: 'hit', label: 'Bass hit', desc: 'CTA / end card pe ek heavy bass thump.' },
    ],
    road: [
      { title: 'Pehla monster fight', desc: 'Protagonist apni story-knowledge se scenario crack karta hai — "knowledge is power" wala payoff.' },
      { title: 'Novel ke "hero" se pehli mulaqat', desc: 'Kahani ka asli hero zinda saamne — fan-favorite entry hook.' },
      { title: 'Special ability reveal', desc: 'Core power system unveil hota hai — series ka asli hook yahan lock hota hai.' },
    ],
    rule: "Har part ke end pe 'agla part' tease karo — cliffhanger chain se follow-through retention badhta hai.",
  },

  system: {
    tag: 'weakest se strongest tak',
    cold: 'Weakest hunter — double dungeon wali raat',
    reasons: [
      'Underdog hook — weakest banda, deadliest jagah (instant sympathy)',
      'Power fantasy ka seed — blue window = unlimited curiosity',
      'Death ka dar + level-up ka lalach — dono ek saath',
      'E-rank se legend tak ka promise — binge trigger',
    ],
    defaultScene:
      'Dungeon ke andar meri poori party dher ho chuki thi. Main bhi marne hi wala tha — tab meri aankhon ke saamne ek neeli window khuli. Meri zindagi badalne wali thi.',
    hook: [
      'Main duniya ka sabse kamzor hunter tha. Log mujhe mazaak mein "sabse weakest" bulate the.',
      'E-rank. Duniya ka sabse neecha rank. Meri jaan ki keemat ek gobhi se bhi kam thi.',
    ],
    setup: [
      'Par ghar chalana tha. Isliye har raid mein sabse aage — maut se aankhein mila ke.',
      'Ek aur raid, ek aur din. Bas us din dungeon ne saare rules tod diye.',
    ],
    turn: [
      'Sab kuch khatam lag raha tha — aur tabhi...',
      'Maut bilkul saamne khadi thi — aur tabhi...',
    ],
    sysIntro: ['Ek neeli roshni chamki, aur thandi si awaaz aayi:'],
    systemLine: 'Player banne ki qualification mil gayi hai.',
    escalate: [
      'Meri saans ruk gayi. Aisa maine kabhi suna nahi tha. Aisi cheez ka to koi wajood hi nahi tha.',
      'Meri aankhon ke saamne woh khula jo is duniya mein kisi aur ko nahi mila tha.',
    ],
    realize: [
      'Jo cheez mujhe maarne aayi thi — wahi meri zindagi ka sabse bada tohfa ban gayi.',
      'Us pal samajh gaya — meri ending nahi, meri shuruaat thi yeh.',
    ],
    resolve: [
      'Ab mere paas sirf ek raasta tha — level up... ya maut.',
      'Aur iss baar, main haarne wala nahi tha.',
    ],
    cta: [
      'Part {n1} mein meri pehli level-up — follow karke rehna, yeh sirf shuruaat thi.',
      'Agla part — pehla hidden quest. Follow kar lo, warna miss ho jaayega.',
    ],
    filler: ['Khoon se lipta haath kaanp raha tha — par aankhon mein pehli baar umeed thi.'],
    visuals: [
      { visual: 'Weak hunter party ke peeche — dim torch light, dungeon corridor', fx: ['handheld shake', 'desaturation'] },
      { visual: 'Party wiped — khoon aur toote hathiyar ground pe', fx: ['slow pan', 'cold grade'] },
      { visual: 'Statue/monster ka low-angle terror shot', fx: ['dutch angle', 'bass pulse'] },
      { visual: 'Blue system window — UI text glitch-in', fx: ['hologram flicker', 'UI sound sync'] },
      { visual: 'Hunter ghutnon pe, muskurate hue — eyes glowing', fx: ['zoom punch', 'rim light'] },
      { visual: 'End card — "Part {n1}: First Level Up" overlay', fx: ['subscribe pop', 'bass hit'] },
    ],
    sounds: [
      { icon: 'pulse', label: 'Heartbeat', desc: 'Dil ki dhadkan escalate hote hue — window ke saath sync.' },
      { icon: 'ding', label: 'UI ding', desc: 'Crisp UI chime jab blue window khule.' },
      { icon: 'hit', label: 'Bass drop', desc: '"Player" line pe heavy drop — goosebumps point.' },
      { icon: 'cut', label: 'Dead silence', desc: 'Maut wale shot pe sab sound cut — 1 sec pure silence.' },
    ],
    road: [
      { title: 'Pehli solo level-up', desc: 'Hidden quest + pehla power spike — viewers ko progression ka maza.' },
      { title: 'Ranking re-test shock', desc: 'Duniya ko pata chalta hai weakest sabse strong hai — reaction payoff.' },
      { title: 'Secret class reveal', desc: 'Unique class/job unlock — series identity lock.' },
    ],
    rule: "Har part mein ek naya 'level moment' do — progression hi is genre ka hook hai.",
  },

  regression: {
    tag: 'maut se pehle, ek aur chance',
    cold: 'Dhoka + maut — aur aankhein 10 saal pehle khuli',
    reasons: [
      'Betrayal hook — sabse bharosemand log, sabse gehra dhoka',
      'Second-chance fantasy — sabko chahiye hoti hai',
      'Future knowledge = god-mode tension',
      'Countdown urgency — har decision pe sab kuch daav pe',
    ],
    defaultScene:
      'Meri jaan lene wale wahi log the jinpe maine sabse zyada bharosa kiya tha. Aankhein band hui... aur jab khuli, main 10 saal pehle apne purane kamre mein tha.',
    hook: [
      'Jis din meri maut hui, us din main sab kuch haar chuka tha. Paisa, naam, bharosa — sab.',
      'Maine apna sab kuch un logon ko de diya. Aur badle mein unhone mujhe maut di.',
    ],
    setup: [
      'Aakhri saans lete waqt bas ek hi khwahish thi — kaash ek mauka aur mil jaaye.',
      'Andhera chha gaya tha. Lekin woh andhera aakhri nahi tha.',
    ],
    turn: ['Aankhein khuli to saans ruk gayi —', 'Phir se saansein aayi. Aur jo dikha uspe yakeen nahi hua —'],
    escalate: [
      'Haath kaanp rahe the. Calender pe wahi taareek thi — sab kuch wapas shuru hone se pehle ki.',
      'Aaine mein main 10 saal jawan tha. Yaadein poori — har dhoka, har chehra yaad tha.',
    ],
    realize: [
      'Yeh koi sapna nahi tha. Yeh mera doosra mauka tha — aur iss baar koi galti nahi.',
      'Iss baar main shikari tha — shikar nahi.',
    ],
    resolve: [
      'Jinkon maine sabse zyada maana tha... unhe kya pata tha ki aane wala toofan main hoon.',
      'Ab har move pehle se pata thi. Aur badla... badla to bas shuru hua tha.',
    ],
    cta: [
      'Part {n1} mein — mera pehla badla. Follow karke rehna, kahani abhi shuru hui hai.',
      'Agle part mein pehla gaddar girega. Follow kar lo — bheed mein khade reh ke dekhna.',
    ],
    filler: ['Kal ka aaina... aur aankhon mein 10 saal aage ka gussa.'],
    visuals: [
      { visual: 'Betrayal scene — toota glass, girte hue protagonist ka silhouette', fx: ['slow motion', 'rain overlay'] },
      { visual: 'Aankhein band — black frame, phir aankh khulti hai (macro)', fx: ['match cut', 'iris transition'] },
      { visual: 'Purana kamra — calendar pe flash, 10 saal pehle ki date', fx: ['date zoom', 'reverse glitch'] },
      { visual: 'Aaine mein jawan chehra — cheekh nahi, muskaan', fx: ['smile creep', 'cold grade'] },
      { visual: 'Gaddaron ke chehre — ek-ek karke photo burn effect', fx: ['photo burn', 'bass sync'] },
      { visual: 'End card — "Part {n1}: Pehla Badla" overlay', fx: ['subscribe pop', 'tick sound'] },
    ],
    sounds: [
      { icon: 'pulse', label: 'Ticking clock', desc: 'Ghadi ki tick-tick — time regression motif.' },
      { icon: 'wind', label: 'Reverse whoosh', desc: 'Aankhein khulne pe reversed sound swell.' },
      { icon: 'cut', label: 'Muffled memories', desc: 'Flashback pe low-pass filter — present mein crisp snap.' },
      { icon: 'hit', label: 'Impact hit', desc: 'Har gaddar ke chehre pe sync hit.' },
    ],
    road: [
      { title: 'Pehla badla', desc: 'Sabse chhota gaddar sabse pehle girta hai — catharsis hit.' },
      { title: 'Hidden power / asset unlock', desc: 'Future knowledge se pehla bada move — smart-protagonist payoff.' },
      { title: 'Mastermind ka chehra', desc: 'Asli villain reveal — stakes double.' },
    ],
    rule: 'Har part mein ek gaddar giro — lekin sabse bada naam end tak chhupa ke rakho.',
  },

  fantasy: {
    tag: 'toota hua disciple, chhupa hua dragon',
    cold: 'Sect se nikaala gaya ladka — usi raat rooh jaag gayi',
    reasons: [
      'Underdog disciple — sabko pasand hai gira hua banda jo uthta hai',
      'Hidden master reveal — 1 second mein zero se god',
      'Sect politics + badla — murim drama cocktail',
      'Mystic visuals — bijli, talwar, rooh — Shorts ke liye gold',
    ],
    defaultScene:
      'Sect ne mujhe nikaal diya kyunki mera core toota hua tha. Usi raat pahaad pe akela baitha tha — tab aasmaan se bijli giri aur mere andar ek hazaron saal purani rooh jaag gayi.',
    hook: [
      'Bara saal. Bara saal sect ki jootiyaan saaf ki maine. Aur aaj unhone mujhe kute ki tarah nikaal diya.',
      'Mera core toota tha. Duniya ke liye main kachara tha — bas duniya ko yeh nahi pata tha ki andar kya so raha hai.',
    ],
    setup: [
      'Maa-baap nahi the. Naam sect ne diya tha, izzat sect ne chheeni.',
      'Us raat pahaad pe baitha tha, haath mein adhoori talwar aur dil mein aag.',
    ],
    turn: ['Aur tabhi aasmaan phata —', 'Usi raat, sab kuch badal gaya —'],
    sysIntro: ['Ek hazaron saal purani awaaz mere andar goonji:'],
    systemLine: 'Aakhirkaar... ek layak jism mila.',
    escalate: [
      'Meri rag-rag mein aag daud gayi. Toota core khud se bharne laga.',
      'Zameen kaanpi. Ped jhuk gaye. Aur meri aankhon ka rang badal gaya.',
    ],
    realize: [
      'Jis rooh ko duniya ne bhagwan maana tha — woh ab mere andar thi.',
      'Sect ne mujhe gira diya tha — par girte hue bhi main utna uncha tha jitna woh kabhi nahi the.',
    ],
    resolve: [
      'Ab sect ko yaad rakhna hoga — jise nikaala tha, woh waapsi zaroor karega.',
      'Talwar wahi thi, haath wahi the — par ab haath mein taakat ka maalik tha.',
    ],
    cta: [
      'Part {n1} mein — pehli talwaar. Follow karke rehna, waapsi ka safar shuru hota hai.',
      'Agle part mein sect ki aankhein khulengi. Follow kar lo — yeh murim hai, yahan badla rasam hai.',
    ],
    filler: ['Chand adhoora tha — jaise mera badla abhi adhoora tha.'],
    visuals: [
      { visual: 'Disciple sect gate ke bahar dhool mein — log thookte hue', fx: ['slow motion', 'dust particles'] },
      { visual: 'Akele pahaad pe raat — taare, hawa mein chhaal', fx: ['wide drone shot', 'wind audio'] },
      { visual: 'Bijli girte hue — frame white-out', fx: ['flash frame', 'screen shake'] },
      { visual: 'Rooh ka manifestation — purana yoddha silhouette peeche', fx: ['double exposure', 'glow trail'] },
      { visual: 'Aankhein khulti hain — iris mein dragon glow', fx: ['macro eye', 'iris glow'] },
      { visual: 'End card — "Part {n1}: Pehli Talwaar" overlay', fx: ['subscribe pop', 'sword shing'] },
    ],
    sounds: [
      { icon: 'wind', label: 'Wind + bells', desc: 'Mandir ki ghantiyaan + hawa — murim atmosphere.' },
      { icon: 'hit', label: 'Thunder crack', desc: 'Bijli pe deep thunder — bass heavy.' },
      { icon: 'drone', label: 'Rumble drone', desc: 'Rooh jaagne pe low sub rumble.' },
      { icon: 'ding', label: 'Sword shing', desc: 'CTA/end card pe talwar ki shing.' },
    ],
    road: [
      { title: 'Hidden master ki training', desc: 'Rooh se seekhna shuru — training montage hook.' },
      { title: 'Sect tournament waapsi', desc: 'Gira hua disciple wapas aata hai — public humiliation reverse.' },
      { title: 'Rooh ka asli naam', desc: 'Master ki asli pehchaan — stakes宇宙的? no — stakes double.' },
    ],
    rule: 'Har part mein ek sect elder ka cheque Tod — power creep dikhana zaroori hai.',
  },

  horror: {
    tag: 'awazein pehle aati hain',
    cold: 'Naya flat, pehli raat — 3:33 baje ki khat-khat',
    reasons: [
      'Curiosity + dar — "iske baad kya hua" chhodna impossible hai',
      'POV realism — real flat, real raat = maximum immersion',
      'Sound-first fear — Shorts pe audio-only bhi kaam karega',
      'Safe thrill — dar dekhna guilty pleasure hai',
    ],
    defaultScene:
      'Naye flat mein pehli hi raat thi. 3:33 baje diwar ke andar se khat-khat aayi. Padosi ne subah kaha — is building mein teesra floor hai hi nahi. Phir seedhiyan upar kahan jaati hain?',
    hook: [
      'Main bhoot-pret mein bilkul yakeen nahi rakhta tha. 14 din pehle tak.',
      'Jo main ab batane wala hoon, iske baad tum bhi raat ko diwar pe kaan nahi rakhoge.',
    ],
    setup: [
      'Sasta rent tha, location acchi thi. Broker ne bola — pichhla kirayeda jaldi mein nikal gaya tha.',
      'Naya sheher, naya flat, nayi zindagi. Kamra number 34.',
    ],
    turn: ['Pehli raat ko 3:33 baje —', 'Sab kuch shaant tha. Tabhi —'],
    escalate: [
      'Khat-khat. Pehle diwar mein, phir farsh ke neeche. Phir... seedhiyon pe.',
      'CCTV dekha — raat 3:33 pe seedhiyan kisi ki thi, par wahan koi tha hi nahi.',
    ],
    realize: [
      'Padosi ne kaha — "is building mein teesra floor hai hi nahi." Mera flat... teesre floor pe tha.',
      'Register mein mera naam 34 ke saamne tha. Upar likha tha — 1974. Yeh flat 50 saal se khali tha.',
    ],
    resolve: [
      'Aur kal raat... khat-khat ne mere naam se bulana shuru kar diya.',
      'Ab problem yeh nahi ki flat mein kya hai. Problem yeh hai — flat mujhe jaane dega ya nahi.',
    ],
    cta: [
      'Part {n1} mein main seedhiyon se upar gaya. Follow karke rehna — agar himmat hai.',
      'Agle part mein main woh recording sunaunga. Follow kar lo... raat 3:33 baje mat dekhna.',
    ],
    filler: ['Kaan mein sirf apni saans... aur seedhiyon pe kisi aur ki.'],
    visuals: [
      { visual: 'Khali flat — door aadha khula, andhera andar', fx: ['static noise', 'low light grain'] },
      { visual: 'Wall clock macro — 3:33 tick', fx: ['time-lapse blur', 'tick sync'] },
      { visual: 'Diwar pe kaan rakhte hue POV', fx: ['muffled audio', 'camera breathe'] },
      { visual: 'Seedhiyon ka top-down shot — kuch dikhta nahi, par feel hota hai', fx: ['negative space', 'sub-bass'] },
      { visual: 'CCTV footage style — timestamp chalta hua', fx: ['VHS noise', 'timestamp overlay'] },
      { visual: 'End card — "Part {n1}: Teesra Floor" red text pe', fx: ['flicker text', 'heartbeat'] },
    ],
    sounds: [
      { icon: 'cut', label: 'Near silence', desc: '90% waqt hush — dar silence mein banta hai.' },
      { icon: 'ding', label: 'Khat-khat', desc: 'Har knock pe dry wood knock — reverb ke saath.' },
      { icon: 'drone', label: 'Infrasound drone', desc: 'Bohot low frequency — feel hota hai, sunta nahi.' },
      { icon: 'hit', label: 'Sting', desc: 'Reveal line pe single shriek sting — phir cut.' },
    ],
    road: [
      { title: 'Teesre floor ka raaz', desc: 'Seedhiyon ke upar kya hai — first look, first scare.' },
      { title: '1974 wali recording', desc: 'Purane kirayeda ki aakhri recording — lore drop.' },
      { title: 'Raat 3:33 ka camera', desc: 'Overnight setup — found-footage climax.' },
    ],
    rule: 'Kabhi poora bhoot mat dikhao — cliffhanger hi asli bhoot hota hai.',
  },

  romance: {
    tag: '10 saal, ek promise, ek invitation',
    cold: '10 saal baad woh mili — shaadi ke card ke saath',
    reasons: [
      '100% relatable — har kisi ka ek "10 saal purana" rishta hota hai',
      'Ek line mein gut-punch — card + promise = instant emotion',
      'Kahaniyan nahi, khamoshiyan bikti hain — pause ka use',
      'Ship payoff — audience do logon ko milate hue dekhna chahti hai',
    ],
    defaultScene:
      '10 saal baad usse mila — shaadi ke card ke saath. Usne kaha "yaad hai woh promise?" — wahi promise jo maine kabhi toda nahi tha, aur kabhi nibha bhi nahi paya.',
    hook: [
      '10 saal pehle maine ek promise kiya tha. 10 saal baad, woh promise mere haath mein shaadi ke card ban ke aaya.',
      'Log kehte hain waqt sab kuch bhula deta hai. Jhooth kehte hain.',
    ],
    setup: [
      'Hum alag sheher, alag zindagi. Bas ek number kabhi delete nahi hua.',
      'Call aayi uski. Awaaz wahi thi. Bas uske saath ek "humm" nahi, ek "haan" judgement tha.',
    ],
    turn: ['Phir usne ek cheez nikali —', 'Coffee table pe usne rakha —'],
    escalate: [
      'Card sona-chamakta hua. Naam uska... par saath wala naam mera nahi tha.',
      'Woh muskura rahi thi — wahi muskaan jo 10 saal pehle barish mein dekhi thi.',
    ],
    realize: [
      '"Yaad hai woh promise?" — ek sawaal, aur 10 saal ki saari safar aankhon ke saamne.',
      'Maine kabhi promise nahi toda tha. Main bas... kabhi keh nahi paaya tha.',
    ],
    resolve: [
      'Shaadi uski thi. Lekin promise... promise ab bhi mera tha.',
      'Card table pe tha. Dil haath pe. Aur waqt... waqt dono ke khilaaf.',
    ],
    cta: [
      'Part {n1} mein pata chalega — main shaadi pe gaya ya promise pe. Follow karke rehna.',
      'Agle part mein woh promise kya tha — sunoge to samjhoge. Follow kar lo.',
    ],
    filler: ['Baithke sirf ek line yaad aayi — "kuch rishtay waqt se bade hote hain."'],
    visuals: [
      { visual: 'Cafe table — do cups, card beech mein, warm tones', fx: ['golden hour', 'shallow DOF'] },
      { visual: 'Card macro — chamakta sona, naam blurred', fx: ['rack focus', 'bokeh'] },
      { visual: 'Flashback — barish mein chhata, duur se silhouette', fx: ['vintage grade', 'rain overlay'] },
      { visual: 'Haath — card ke beech fingers, hesitation', fx: ['slow push', 'skin detail'] },
      { visual: 'Aankhein — ek paani sa, ek smile sa (split)', fx: ['split frame', 'hold 2s'] },
      { visual: 'End card — "Promise kya tha? Part {n1}"', fx: ['soft fade', 'piano note'] },
    ],
    sounds: [
      { icon: 'drone', label: 'Piano bed', desc: 'Soft sad piano — 3 notes ka loop.' },
      { icon: 'wind', label: 'Rain foley', desc: 'Flashback mein halki barish — nostalgia trigger.' },
      { icon: 'cut', label: 'Ambient cut', desc: 'Promise line pe saara ambient cut — sirf awaaz.' },
      { icon: 'pulse', label: 'Single heartbeat', desc: 'Card reveal pe ek heartbeat — phir silence.' },
    ],
    road: [
      { title: 'Woh promise kya tha', desc: 'Barish wali raat ka flashback — promise reveal.' },
      { title: 'Shaadi wala din', desc: 'Main pahuncha ya nahi — decision cliffhanger.' },
      { title: 'Mandap ya dil', desc: 'Final choice — series payoff.' },
    ],
    rule: 'Emotion peak pe kaato — kabhi resolution full mein mat do, hamesha next part pe.',
  },

  action: {
    tag: 'akela andar, 40 log andar',
    cold: '48 ghante pehle team mare — ab main warehouse ke saamne',
    reasons: [
      'In-medias-res — kahani beech fight se shuru, context baad mein',
      'One vs many — ultimate power fantasy Shorts format',
      'Score-settle hook — "team ko maara" = personal stakes',
      'Choreography ka showcase — edit ka asli maza',
    ],
    defaultScene:
      '48 ghante pehle meri poori team ko maar diya gaya. Ab main us warehouse ke saamne khada tha — akela, bina backup ke. Andar 40 log the. Aur mujhe sirf ek naam chahiye tha.',
    hook: [
      'Mere paas na Hathiyar ka stock tha, na koi backup. Sirf 48 ghante purana gussa tha.',
      'Unhone meri team ko maara aur socha main bhag gaya. Main ginti kar raha tha — 1 se 40 tak.',
    ],
    setup: [
      'Team meri family thi. Raat-din ek saath. Aur ek raat mein sab khatam.',
      'Police apna kaam karti, main apna. Warehouse do baje khalee.',
    ],
    turn: ['Darwaza khula — aur andheri gallery mein main utra —', 'Torch jali. Kadam aage badhe —'],
    escalate: [
      'Pehle 10 ne socha main pagal hoon. Baaki 30 ne bhagna shuru kiya — andar ki taraf, bahar ki taraf nahi.',
      'Number 17 ne glass phoda. Number 23 ko maine phone se hi giraya. Ab baaki bache 17.',
    ],
    realize: [
      'Mujhe marne nahi aaya tha. Mujhe ek naam chahiye tha — jisne order diya tha.',
      '40 log mujhe rokne nahi aaye the. Woh sirf der thi — asli shikar to saamne tha.',
    ],
    resolve: [
      'Sabse aakhir mein ek darwaza tha. Uske peeche — mere sawalon ka jawab.',
      'Number 40 girta hua — aur meri aankhein us darwaze pe jahan asli khiladi baitha tha.',
    ],
    cta: [
      'Part {n1} mein us darwaze ke peeche ka sach — follow karke rehna, abhi trailer tha.',
      'Agle part mein 40 ka hisaab poora. Follow kar lo — warna number 41 mat kehna.',
    ],
    filler: ['Dil ki dhadkan aur boot ki aahat — dono ek hi rhythm mein.'],
    visuals: [
      { visual: 'Warehouse night exterior — bike, silhouette, marammat light', fx: ['anamorphic flare', 'smoke FX'] },
      { visual: 'Photo wall — team ki tasveerein, red crosses', fx: ['flash frames', 'heartbeat sync'] },
      { visual: 'Long corridor walk — back follow, lights flicker', fx: ['oner follow', 'flicker sync'] },
      { visual: 'First contact — ek punch, camera shake, 3 down', fx: ['speed ramp', 'impact frames'] },
      { visual: 'Counting overlay — 17/23/40 counter UI', fx: ['HUD counter', 'hit sync'] },
      { visual: 'End card — "Part {n1}: Number 41" text punch', fx: ['subscribe pop', 'bass hit'] },
    ],
    sounds: [
      { icon: 'drone', label: 'Tension drone', desc: 'Rumble + metal groans — warehouse echo.' },
      { icon: 'hit', label: 'Impact hits', desc: 'Har punch pe dry thud — no music, sirf foley.' },
      { icon: 'cut', label: 'Foley-only mode', desc: 'Fight ke beech music hatado — boots + breath + thud.' },
      { icon: 'ding', label: 'Counter tick', desc: 'Number counter pe mechanical tick.' },
    ],
    road: [
      { title: 'Number 41 — boss reveal', desc: 'Darwaze ke peeche ka chehra — koi expected nahi.' },
      { title: 'Order dene wala kaun', desc: 'Mastermind ka connection — stakes personal se political.' },
      { title: 'Team ka sach', desc: 'Ek member zinda tha — aur woh gaddar tha.' },
    ],
    rule: 'Fight hamesha beech mein kaato — "goli chalne se pehle" hi best cut point hai.',
  },

  scifi: {
    tag: 'signal aaya, par bheja maine nahi',
    cold: 'Mars colony ka aakhri message — recording mein meri apni awaaz',
    reasons: [
      'Ek line ka concept — poora short ek idea pe, clarity king hai',
      'Paradox hook — "meri awaaz jo maine bola hi nahi"',
      'Big scale + zero budget — VO + sound design mein hi poora scene',
      'Mind-bend ending — comments mein theory war = reach',
    ],
    defaultScene:
      'Mars colony ka aakhri message aaya — 4 minute ki recording. Recording mein meri apni awaaz thi. Par maine woh call kabhi kiya hi nahi. Aur date... date 6 mahine aage ki thi.',
    hook: [
      'Humne socha tha akele hain is universe mein. Kal raat ko yakeen ho gaya — hum kabhi akele the hi nahi.',
      'Space mein awaaz nahi jaati. Phir bhi har raat 2:04 baje, woh signal aata tha.',
    ],
    setup: [
      'Deep-space listening post. 6 mahine ki shift. Sirf main, machines aur static.',
      'Kaam simple tha — suno, record karo, report karo. 14 minute ka delay. Koi jaldi nahi thi.',
    ],
    turn: ['Us raat signal aaya — aur mere haath kaanpne lage —', 'Pehli baar signal ne pattern follow nahi kiya —'],
    sysIntro: ['Static ke beech se awaaz nikli — bilkul meri awaaz:'],
    systemLine: 'Woh aa rahe hain. Humse pehle hi pahunch chuke hain.',
    escalate: [
      'Recording 4 minute 22 second ki thi. Aakhri 10 second mein — cheekh. Meri cheekh.',
      'Timestamp dekha to khoon jam gaya — 14 minute ka delay nahi tha. 6 mahine aage ka tha.',
    ],
    realize: [
      'Yeh message Mars se nahi aa raha tha. Yeh message future se aa raha tha — ya kisi aur se jo mujhe jaanta tha.',
      'Duniya ko report karne se pehle maine ek aur cheez dekhi — recording mein teesri awaaz thi.',
    ],
    resolve: [
      'Agar yeh sach tha... to mere paas sirf 6 mahine bache the.',
      'Aur sabse ajeeb baat? Signal dobara aaya tha — aaj raat 2:04 baje.',
    ],
    cta: [
      'Part {n1} mein — doosri recording. Follow karke rehna, warna 2:04 wali raat mat sunna.',
      'Agle part mein teesri awaaz ka owner. Follow kar lo — warna baad mein mat kehna bataya nahi.',
    ],
    filler: ['Machine quiet thi. Signal quiet tha. Sirf meri saans 4 minute peeche chal rahi thi.'],
    visuals: [
      { visual: 'Listening post night — screens, coffee, red-shift glow', fx: ['CRT grain', 'scanlines'] },
      { visual: 'Waveform screen — signal spike, cursor rok ke', fx: ['UI zoom', 'green-on-black'] },
      { visual: 'Headphones close-up — canal se jaati hui roshni', fx: ['macro shot', 'shallow DOF'] },
      { visual: 'Recording text log — auto-transcript scroll', fx: ['typewriter', 'timestamp roll'] },
      { visual: 'Mars surface stock — reddish horizon, signal arc', fx: ['slow zoom', 'star parallax'] },
      { visual: 'End card — "Part {n1}: Teesri Awaaz" type-on', fx: ['signal glitch', 'clock chime'] },
    ],
    sounds: [
      { icon: 'drone', label: 'Static bed', desc: 'Radio static + low hum — sci-fi atmosphere.' },
      { icon: 'ding', label: 'Signal ping', desc: 'Har signal pe sonar ping — pattern banao.' },
      { icon: 'wind', label: 'Reverse vocal', desc: 'Recording ke neeche reversed voice layer — uneasy feel.' },
      { icon: 'hit', label: 'Deep boom', desc: '"Teesri awaaz" line pe sub-bass boom.' },
    ],
    road: [
      { title: 'Doosri recording — 6 mahine aage', desc: 'Future main — kya hua tha colony mein, footage decode.' },
      { title: 'Teesri awaaz ka owner', desc: 'Jo bolta tha woh insaan nahi tha — par pattern tha.' },
      { title: '2:04 wali raat', desc: 'Signal ka asli source — reveal = series peak.' },
    ],
    rule: 'Har part mein ek aur layer kholo — clear answer kabhi mat do, theories ko janam do.',
  },
};

const EN: Record<GenreKey, GenreBank> = {
  apocalypse: {
    tag: 'the world ends, the scenario begins',
    cold: 'Chapter 1 — the trigger moment of "{title}"',
    reasons: [
      'Relatable hook — an ordinary person on an ordinary day',
      'Instant twist — the world becomes a scenario before your eyes',
      'Natural character intro — zero info-dump',
      'A self-contained "WTF just happened" in 60s — perfect Short hook',
    ],
    defaultScene:
      'I was sitting on the subway, like every other day. Then a voice — not human — echoed across the entire world. People screamed, and something that was not human appeared.',
    hook: [
      "Ten years. Ten years I spent on a single story — '{title}'. Everyone dropped it, called it boring. I was the only one who finished it.",
      "The day the world changed, I was in my routine — ordinary guy, ordinary day. Only one thing set me apart: '{title}' was never just a story to me.",
    ],
    setup: [
      'Same daily routine. Same crowd, same exhaustion, same world rushing past the window.',
      'That day was like every other day. A perfectly ordinary evening — the last ordinary evening.',
    ],
    turn: ['And then... something happened I could never have imagined.', 'And then — the real story of the world began.'],
    sysIntro: ['A voice echoed — one no human throat could produce:', 'One single message rang out across the world:'],
    systemLine: 'The first scenario has begun.',
    escalate: [
      'People screamed. Panic scattered the crowd. My breath stopped — but my mind raced.',
      'Screams everywhere. Glass broke, lights died, and the crowd trampled for survival.',
    ],
    realize: [
      "This wasn't just a story anymore. It was becoming my world's new reality.",
      'What I had read — pure imagination — now stood alive in front of me.',
    ],
    resolve: [
      'And the worst part? Only I knew what was about to happen next.',
      'But one thing only I knew — what the next page of this story said.',
    ],
    cta: [
      "In part {n1}, I'll tell you how I survived — stay tuned, this was only the beginning.",
      'Next part — the first scenario, the first blood. Follow if you dare.',
    ],
    filler: ['My heartbeat thundered in my ears. My hands shook — but my mind was calm.'],
    visuals: [
      { visual: 'Man reading on a subway seat — webtoon panel / AI art', fx: ['slow push-in', 'film grain'] },
      { visual: 'Close-up, book/closing screen, eyes look up', fx: ['match cut', 'soft vignette'] },
      { visual: 'Subway interior wide — flickering lights, eerie grade', fx: ['light flicker', 'cold grade'] },
      { visual: 'System message as on-screen text — glitch reveal, red accent', fx: ['red flash', 'glitch text', 'shake'] },
      { visual: 'Panic — running crowd, creature silhouette at the door', fx: ['sudden silence', 'whip pan'] },
      { visual: 'Protagonist close-up — determined expression', fx: ['heartbeat sync', 'tight crop'] },
      { visual: 'End card — "Part {n1} coming" overlay', fx: ['subscribe pop', 'bass hit'] },
    ],
    sounds: [
      { icon: 'drone', label: 'Suspense drone', desc: 'Low rumble from the very start.' },
      { icon: 'ding', label: 'System ding', desc: 'Glitch ding when the system line lands.' },
      { icon: 'cut', label: 'Silence cut', desc: 'Cut to silence at the panic scene, then peak tense music.' },
      { icon: 'hit', label: 'Bass hit', desc: 'Heavy thump under the CTA / end card.' },
    ],
    road: [
      { title: 'First monster fight', desc: 'The protagonist cracks the scenario with story-knowledge — the "knowledge is power" payoff.' },
      { title: 'Meeting the novel\'s hero', desc: 'The story\'s true hero appears alive — fan-favorite entry hook.' },
      { title: 'Special ability reveal', desc: 'The core power system unlocks — the series hook lands here.' },
    ],
    rule: 'Tease the next part at every ending — cliffhanger chains drive follow-through retention.',
  },

  system: {
    tag: 'from weakest to strongest',
    cold: 'The weakest hunter — the night of the double dungeon',
    reasons: [
      'Underdog hook — weakest person in the deadliest place',
      'Power-fantasy seed — the blue window means infinite curiosity',
      'Fear of death + lure of leveling — both at once',
      'E-rank to legend promise — a binge trigger',
    ],
    defaultScene:
      'My entire party lay dead inside the dungeon. I was next — until a blue window opened before my eyes. My life was about to change forever.',
    hook: [
      'I was the weakest hunter alive. They mocked me as "humanity\'s weakest."',
      'E-rank. The bottom of the bottom. My life was worth less than the dungeon\'s cheapest loot.',
    ],
    setup: [
      'But bills don\'t pay themselves. So I stood at the front of every raid — staring death down.',
      'One more raid, one more day. Except that day, the dungeon broke every rule.',
    ],
    turn: ['It was all over — and then...', 'Death stood inches away — and then...'],
    sysIntro: ['A blue light flashed, and a cold voice spoke:'],
    systemLine: 'You have acquired the qualifications to become a Player.',
    escalate: [
      'My breath stopped. Nothing like this had ever been recorded. Nothing like this existed.',
      'Something opened before me that no one else on Earth had ever received.',
    ],
    realize: [
      'The thing that came to kill me became the greatest gift of my life.',
      'In that moment I knew — this wasn\'t my ending. It was my beginning.',
    ],
    resolve: ['Now there was only one path left — level up... or die.', 'And this time, I wasn\'t going to lose.'],
    cta: [
      'Part {n1} — my first level-up. Stay tuned, this was only the beginning.',
      'Next part — the first hidden quest. Follow now, or miss it forever.',
    ],
    filler: ['My bloodied hand trembled — but for the first time, my eyes held hope.'],
    visuals: [
      { visual: 'Weak hunter behind the party — dim torchlight, dungeon corridor', fx: ['handheld shake', 'desaturation'] },
      { visual: 'Party wiped — blood and broken weapons on the ground', fx: ['slow pan', 'cold grade'] },
      { visual: 'Low-angle terror shot of the statue/monster', fx: ['dutch angle', 'bass pulse'] },
      { visual: 'Blue system window — UI text glitches in', fx: ['hologram flicker', 'UI sync'] },
      { visual: 'Hunter on his knees, grinning — eyes glowing', fx: ['zoom punch', 'rim light'] },
      { visual: 'End card — "Part {n1}: First Level Up" overlay', fx: ['subscribe pop', 'bass hit'] },
    ],
    sounds: [
      { icon: 'pulse', label: 'Heartbeat', desc: 'Escalating heartbeat — synced to the window.' },
      { icon: 'ding', label: 'UI ding', desc: 'Crisp chime when the blue window opens.' },
      { icon: 'hit', label: 'Bass drop', desc: 'Heavy drop on the "Player" line — goosebumps point.' },
      { icon: 'cut', label: 'Dead silence', desc: 'One full second of pure silence on the death shot.' },
    ],
    road: [
      { title: 'First solo level-up', desc: 'Hidden quest + first power spike — progression dopamine.' },
      { title: 'Ranking re-test shock', desc: 'The world learns the weakest is the strongest — reaction payoff.' },
      { title: 'Secret class reveal', desc: 'Unique class unlock — the series identity locks in.' },
    ],
    rule: 'Give one new "level moment" per part — progression IS this genre\'s hook.',
  },

  regression: {
    tag: 'one more chance before death',
    cold: 'Betrayal + death — and eyes open 10 years in the past',
    reasons: [
      'Betrayal hook — trusted faces, deepest knives',
      'Second-chance fantasy — universal wish fulfillment',
      'Future knowledge = god-mode tension',
      'Countdown urgency — everything rides on every choice',
    ],
    defaultScene:
      'The ones who killed me were the ones I trusted most. My eyes closed... and when they opened, I was in my old room, ten years in the past.',
    hook: [
      'On the day I died, I had lost everything. Money, name, trust — all of it.',
      'I gave those people everything I had. In return, they gave me death.',
    ],
    setup: [
      'With my last breath, I wished for one thing — one more chance.',
      'Darkness fell. But it wasn\'t the final darkness.',
    ],
    turn: ['My eyes opened and my breath stopped —', 'Air returned. And what I saw, I couldn\'t believe —'],
    escalate: [
      'My hands shook. The calendar showed the date — everything was about to begin again.',
      'The mirror showed me ten years younger. Memories intact — every betrayal, every face.',
    ],
    realize: [
      'This was no dream. This was my second chance — and this time, no mistakes.',
      'This time, I was the hunter — not the prey.',
    ],
    resolve: [
      'The people I trusted most had no idea — the coming storm was me.',
      'Every move was already known. And revenge... revenge had only begun.',
    ],
    cta: [
      'Part {n1} — my first revenge. Follow along, the story has just begun.',
      'Next part, the first traitor falls. Follow — you\'ll want a front-row seat.',
    ],
    filler: ['Yesterday\'s mirror... and eyes carrying ten years of future rage.'],
    visuals: [
      { visual: 'Betrayal scene — shattered glass, falling silhouette', fx: ['slow motion', 'rain overlay'] },
      { visual: 'Eyes close — black frame, then an iris opens (macro)', fx: ['match cut', 'iris transition'] },
      { visual: 'Old room — calendar flash, date 10 years back', fx: ['date zoom', 'reverse glitch'] },
      { visual: 'Younger face in the mirror — not a scream, a smile', fx: ['smile creep', 'cold grade'] },
      { visual: 'Traitors\' faces — burning photo effect, one by one', fx: ['photo burn', 'bass sync'] },
      { visual: 'End card — "Part {n1}: First Revenge" overlay', fx: ['subscribe pop', 'tick sound'] },
    ],
    sounds: [
      { icon: 'pulse', label: 'Ticking clock', desc: 'Tick-tock motif for the time regression.' },
      { icon: 'wind', label: 'Reverse whoosh', desc: 'Reversed swell as the eyes open.' },
      { icon: 'cut', label: 'Muffled memories', desc: 'Low-pass flashbacks, crisp snaps to present.' },
      { icon: 'hit', label: 'Impact hit', desc: 'Synced hit on every traitor\'s face.' },
    ],
    road: [
      { title: 'First revenge', desc: 'The smallest traitor falls first — pure catharsis.' },
      { title: 'Hidden asset unlock', desc: 'First big play with future knowledge — smart-protagonist payoff.' },
      { title: 'The mastermind\'s face', desc: 'The true villain is revealed — stakes double.' },
    ],
    rule: 'Drop one traitor per part — but hide the biggest name until the end.',
  },

  fantasy: {
    tag: 'broken disciple, hidden dragon',
    cold: 'Expelled from the sect — that night, the soul awakened',
    reasons: [
      'Underdog disciple — everyone roots for the fallen one who rises',
      'Hidden master reveal — zero to god in one second',
      'Sect politics + revenge — the murim drama cocktail',
      'Mystic visuals — lightning, swords, souls — Shorts gold',
    ],
    defaultScene:
      'The sect expelled me because my core was shattered. That night, alone on the mountain, lightning struck — and a thousand-year-old soul awakened inside me.',
    hook: [
      'Twelve years. Twelve years I polished the sect\'s boots. Today they threw me out like a dog.',
      'My core was broken. To the world, I was trash — they just didn\'t know what slept inside.',
    ],
    setup: [
      'No parents. The sect gave me a name; the sect took back my honor.',
      'That night on the mountain: a broken sword in hand, fire in the heart.',
    ],
    turn: ['And then the sky split open —', 'That night, everything changed —'],
    sysIntro: ['A thousand-year-old voice echoed within me:'],
    systemLine: 'Finally... a worthy vessel.',
    escalate: [
      'Fire raced through my veins. The shattered core began to refill itself.',
      'The ground shook. Trees bent. And the color of my eyes changed.',
    ],
    realize: [
      'The soul the world once worshipped as a god — now lived inside me.',
      'They cast me down — yet even fallen, I stood higher than they ever would.',
    ],
    resolve: [
      'Now the sect must remember — the one they expelled always returns.',
      'Same sword, same hands — but now the hands held a master of power.',
    ],
    cta: [
      'Part {n1} — the first sword. Follow along, the return journey begins.',
      'Next part, the sect\'s eyes will open. Follow — in murim, revenge is a rite.',
    ],
    filler: ['The moon was half — like my revenge, still unfinished.'],
    visuals: [
      { visual: 'Disciple in the dust outside the sect gates — people spitting', fx: ['slow motion', 'dust particles'] },
      { visual: 'Alone on the mountain at night — stars, drifting mist', fx: ['wide drone shot', 'wind audio'] },
      { visual: 'Lightning strike — frame white-out', fx: ['flash frame', 'screen shake'] },
      { visual: 'Soul manifestation — ancient warrior silhouette behind', fx: ['double exposure', 'glow trail'] },
      { visual: 'Eyes open — dragon glow in the iris', fx: ['macro eye', 'iris glow'] },
      { visual: 'End card — "Part {n1}: The First Sword" overlay', fx: ['subscribe pop', 'sword shing'] },
    ],
    sounds: [
      { icon: 'wind', label: 'Wind + bells', desc: 'Temple bells and wind — murim atmosphere.' },
      { icon: 'hit', label: 'Thunder crack', desc: 'Deep bass thunder on the lightning.' },
      { icon: 'drone', label: 'Rumble drone', desc: 'Low sub rumble as the soul wakes.' },
      { icon: 'ding', label: 'Sword shing', desc: 'Blade shing on the CTA / end card.' },
    ],
    road: [
      { title: 'Training with the hidden master', desc: 'Learning from the soul begins — montage hook.' },
      { title: 'Return to the sect tournament', desc: 'The expelled disciple returns — public humiliation, reversed.' },
      { title: 'The soul\'s true name', desc: 'The master\'s real identity — stakes double.' },
    ],
    rule: 'Break one sect elder per part — visible power creep is mandatory.',
  },

  horror: {
    tag: 'the sounds arrive first',
    cold: 'New flat, first night — knocking at 3:33 AM',
    reasons: [
      'Curiosity + fear — impossible to skip "what happened next"',
      'POV realism — real flat, real night = maximum immersion',
      'Sound-first fear — works on Shorts even audio-only',
      'Safe thrill — fear-watching is a guilty pleasure',
    ],
    defaultScene:
      'First night in the new flat. At 3:33 AM, knocking came from inside the wall. The neighbor said the building has no third floor. Then where do the stairs lead?',
    hook: [
      'I never believed in ghosts. Until 14 days ago.',
      'What I\'m about to tell you will make you think twice before pressing your ear to a wall.',
    ],
    setup: [
      'Cheap rent, great location. The broker said the last tenant left in a hurry.',
      'New city, new flat, new life. Room number 34.',
    ],
    turn: ['On the first night, at 3:33 AM —', 'Everything was silent. Then —'],
    escalate: [
      'Knock-knock. First inside the wall, then beneath the floor. Then... on the stairs.',
      'Checked the CCTV — at 3:33 the stairwell moved, but no one was there.',
    ],
    realize: [
      'The neighbor said, "this building has no third floor." My flat... was on the third floor.',
      'My name sat beside 34 in the register. Above it: 1974. The flat had been empty for 50 years.',
    ],
    resolve: [
      'And last night... the knocking started calling my name.',
      'The problem isn\'t what\'s in the flat. It\'s whether the flat will let me leave.',
    ],
    cta: [
      'In part {n1}, I climb the stairs. Follow along — if you dare.',
      'Next part, I\'ll play that recording. Follow... just don\'t watch at 3:33 AM.',
    ],
    filler: ['In my ears: my own breath... and someone else\'s, on the stairs.'],
    visuals: [
      { visual: 'Empty flat — door ajar, darkness inside', fx: ['static noise', 'low-light grain'] },
      { visual: 'Wall clock macro — ticking to 3:33', fx: ['time-lapse blur', 'tick sync'] },
      { visual: 'POV with ear pressed to the wall', fx: ['muffled audio', 'camera breathe'] },
      { visual: 'Top-down stairwell shot — nothing visible, everything felt', fx: ['negative space', 'sub-bass'] },
      { visual: 'CCTV-style footage — running timestamp', fx: ['VHS noise', 'timestamp overlay'] },
      { visual: 'End card — "Part {n1}: The Third Floor" on red text', fx: ['flicker text', 'heartbeat'] },
    ],
    sounds: [
      { icon: 'cut', label: 'Near silence', desc: '90% hush — fear is built in silence.' },
      { icon: 'ding', label: 'Knock-knock', desc: 'Dry wood knock with reverb on every knock.' },
      { icon: 'drone', label: 'Infrasound drone', desc: 'Ultra-low frequency — felt, not heard.' },
      { icon: 'hit', label: 'Sting', desc: 'Single shriek sting on the reveal — then cut.' },
    ],
    road: [
      { title: 'The secret of the third floor', desc: 'What\'s up the stairs — first look, first scare.' },
      { title: 'The 1974 recording', desc: 'Last tenant\'s final recording — lore drop.' },
      { title: 'The 3:33 AM camera', desc: 'Overnight setup — found-footage climax.' },
    ],
    rule: 'Never show the full ghost — the cliffhanger IS the ghost.',
  },

  romance: {
    tag: '10 years, one promise, one invitation',
    cold: '10 years later she returned — with a wedding card',
    reasons: [
      '100% relatable — everyone has a "10 years ago" person',
      'One-line gut punch — card + promise = instant emotion',
      'Silences sell more than dialogue — use the pause',
      'Ship payoff — audiences want two people brought together',
    ],
    defaultScene:
      'Ten years later she found me — holding a wedding card. "Remember that promise?" she asked. The promise I never broke... and never got to keep.',
    hook: [
      'Ten years ago I made a promise. Ten years later, that promise arrived in my hands as a wedding card.',
      'They say time heals everything. They lie.',
    ],
    setup: [
      'Different cities, different lives. Only one number was never deleted.',
      'Her call came. Same voice. Just a different kind of yes at the end of it.',
    ],
    turn: ['Then she took out one thing —', 'On the café table, she placed —'],
    escalate: [
      'A glittering card. Her name... but the name beside it wasn\'t mine.',
      'She was smiling — the same smile from the rain, ten years ago.',
    ],
    realize: [
      '"Remember the promise?" — one question, and ten years flashed before my eyes.',
      'I never broke that promise. I just... never said it out loud.',
    ],
    resolve: [
      'The wedding was hers. But the promise... the promise was still mine.',
      'The card on the table. The heart on the sleeve. And time — against them both.',
    ],
    cta: [
      'Part {n1} — do I go to the wedding, or to the promise? Follow along.',
      'Next part, what the promise was — hear it and you\'ll understand. Follow.',
    ],
    filler: ['Only one line came to mind — "some bonds outgrow time itself."'],
    visuals: [
      { visual: 'Café table — two cups, card between them, warm tones', fx: ['golden hour', 'shallow DOF'] },
      { visual: 'Card macro — glittering gold, names blurred', fx: ['rack focus', 'bokeh'] },
      { visual: 'Flashback — an umbrella in the rain, silhouette from afar', fx: ['vintage grade', 'rain overlay'] },
      { visual: 'Hands — fingers at the card\'s edge, hesitation', fx: ['slow push', 'skin detail'] },
      { visual: 'Eyes — one teary, one smiling (split)', fx: ['split frame', 'hold 2s'] },
      { visual: 'End card — "What was the promise? Part {n1}"', fx: ['soft fade', 'piano note'] },
    ],
    sounds: [
      { icon: 'drone', label: 'Piano bed', desc: 'Soft sad piano — a three-note loop.' },
      { icon: 'wind', label: 'Rain foley', desc: 'Light rain under the flashback — nostalgia trigger.' },
      { icon: 'cut', label: 'Ambient cut', desc: 'Cut all ambience on the promise line — voice only.' },
      { icon: 'pulse', label: 'Single heartbeat', desc: 'One heartbeat on the card reveal — then silence.' },
    ],
    road: [
      { title: 'What the promise was', desc: 'Flashback to that rainy night — promise reveal.' },
      { title: 'The wedding day', desc: 'Did I show up or not — decision cliffhanger.' },
      { title: 'The altar or the heart', desc: 'Final choice — series payoff.' },
    ],
    rule: 'Cut at the emotion peak — never give the full resolution, always push to the next part.',
  },

  action: {
    tag: 'one man outside, forty inside',
    cold: '48 hours since the team fell — now I stand at the warehouse',
    reasons: [
      'In-medias-res — the story starts mid-fight, context later',
      'One vs many — the ultimate power fantasy for Shorts',
      'Score-settle hook — "they killed my team" = personal stakes',
      'A choreography showcase — an editor\'s playground',
    ],
    defaultScene:
      '48 hours ago my entire team was killed. Now I stood outside that warehouse — alone, no backup. Forty men inside. And I needed just one name.',
    hook: [
      'I had no arsenal, no backup. Just 48 hours of pure rage.',
      'They killed my team and assumed I ran. I was busy counting — one to forty.',
    ],
    setup: [
      'That team was my family. Day and night, side by side. Gone in one night.',
      'The police do their job. I do mine. Warehouse, 2 AM.',
    ],
    turn: ['The door opened — and I walked into the dark gallery —', 'The torch flicked on. Boots forward —'],
    escalate: [
      'The first ten thought I was crazy. The other thirty started running — deeper in, not out.',
      'Number 17 tried glass. Number 23 fell to a phone. Seventeen left.',
    ],
    realize: [
      'I didn\'t come to kill. I came for one name — the one who gave the order.',
      'Those forty weren\'t there to stop me. They were just a delay — the real prey was ahead.',
    ],
    resolve: [
      'At the very end stood one door. Behind it — my answers.',
      'Number 40 hit the floor — and my eyes locked on the door where the real player sat.',
    ],
    cta: [
      'Part {n1} — the truth behind that door. Follow along, this was just the trailer.',
      'Next part, all forty accounted for. Follow — or don\'t call yourself number 41.',
    ],
    filler: ['Heartbeat and bootsteps — both on the same rhythm.'],
    visuals: [
      { visual: 'Warehouse exterior at night — bike, silhouette, sodium light', fx: ['anamorphic flare', 'smoke FX'] },
      { visual: 'Photo wall — team pictures, red crosses', fx: ['flash frames', 'heartbeat sync'] },
      { visual: 'Long corridor walk — follow from behind, flickering lights', fx: ['oner follow', 'flicker sync'] },
      { visual: 'First contact — one punch, camera shake, three down', fx: ['speed ramp', 'impact frames'] },
      { visual: 'Counting overlay — 17/23/40 counter UI', fx: ['HUD counter', 'hit sync'] },
      { visual: 'End card — "Part {n1}: Number 41" text punch', fx: ['subscribe pop', 'bass hit'] },
    ],
    sounds: [
      { icon: 'drone', label: 'Tension drone', desc: 'Rumble + metal groans — warehouse echo.' },
      { icon: 'hit', label: 'Impact hits', desc: 'Dry thud on every punch — no music, just foley.' },
      { icon: 'cut', label: 'Foley-only mode', desc: 'Strip music mid-fight — boots, breath, thud.' },
      { icon: 'ding', label: 'Counter tick', desc: 'Mechanical tick on the number counter.' },
    ],
    road: [
      { title: 'Number 41 — the boss reveal', desc: 'The face behind the door — nobody expects it.' },
      { title: 'Who gave the order', desc: 'The mastermind connection — stakes go from personal to political.' },
      { title: 'The truth about the team', desc: 'One member survived — and he was the traitor.' },
    ],
    rule: 'Always cut mid-fight — "just before the trigger" is the perfect cut point.',
  },

  scifi: {
    tag: 'a signal arrived — but I never sent it',
    cold: 'The Mars colony\'s last message — with my own voice in it',
    reasons: [
      'One-line concept — the entire short rides a single idea',
      'Paradox hook — "my voice, which I never recorded"',
      'Big scale, zero budget — VO + sound design carries it all',
      'Mind-bend ending — theory wars in comments = reach',
    ],
    defaultScene:
      'The Mars colony\'s final message arrived — a 4-minute recording. The voice in it was mine. But I never made that call. And the date... was six months in the future.',
    hook: [
      'We thought we were alone in this universe. Last night, it was confirmed — we never were.',
      'Sound cannot travel in space. Yet every night at 2:04 AM, the signal arrived.',
    ],
    setup: [
      'Deep-space listening post. A six-month shift. Just me, machines, and static.',
      'Simple job — listen, record, report. A 14-minute delay. Nobody was in a hurry.',
    ],
    turn: ['That night the signal came — and my hands began to shake —', 'For the first time, the signal broke its pattern —'],
    sysIntro: ['Through the static came a voice — unmistakably mine:'],
    systemLine: 'They are coming. They arrived before us.',
    escalate: [
      'The recording ran 4 minutes 22 seconds. The last 10 seconds — a scream. My scream.',
      'Then I saw the timestamp and my blood froze — it wasn\'t 14 minutes delayed. It was six months ahead.',
    ],
    realize: [
      'This message wasn\'t coming from Mars. It was coming from the future — or from someone who knew me.',
      'Before reporting to the world, I noticed one more thing — there was a third voice in the recording.',
    ],
    resolve: [
      'If this was true... I had only six months left.',
      'And the strangest part? The signal came again — tonight, at 2:04 AM.',
    ],
    cta: [
      'Part {n1} — the second recording. Follow along, or skip the night of 2:04.',
      'Next part, the owner of the third voice. Follow — don\'t say I didn\'t warn you.',
    ],
    filler: ['The machines were quiet. The signal was quiet. Only my breath ran four minutes behind.'],
    visuals: [
      { visual: 'Listening post at night — screens, coffee, red-shift glow', fx: ['CRT grain', 'scanlines'] },
      { visual: 'Waveform screen — signal spike, cursor frozen', fx: ['UI zoom', 'green-on-black'] },
      { visual: 'Headphones close-up — light leaking through', fx: ['macro shot', 'shallow DOF'] },
      { visual: 'Recording text log — auto-transcript scrolling', fx: ['typewriter', 'timestamp roll'] },
      { visual: 'Mars surface stock — reddish horizon, signal arc', fx: ['slow zoom', 'star parallax'] },
      { visual: 'End card — "Part {n1}: The Third Voice" typed on', fx: ['signal glitch', 'clock chime'] },
    ],
    sounds: [
      { icon: 'drone', label: 'Static bed', desc: 'Radio static + low hum — sci-fi atmosphere.' },
      { icon: 'ding', label: 'Signal ping', desc: 'Sonar ping on every signal — build a pattern.' },
      { icon: 'wind', label: 'Reverse vocal', desc: 'Reversed voice layer beneath the recording — uneasy.' },
      { icon: 'hit', label: 'Deep boom', desc: 'Sub-bass boom on the "third voice" line.' },
    ],
    road: [
      { title: 'The second recording — six months ahead', desc: 'Future me — what happened at the colony, decoded footage.' },
      { title: 'Owner of the third voice', desc: 'The speaker wasn\'t human — but there was a pattern.' },
      { title: 'The night of 2:04', desc: 'The signal\'s true source — the reveal peaks the series.' },
    ],
    rule: 'Open one more layer per part — never answer cleanly, give birth to theories.',
  },
};

export const GENRE_LIST: { key: GenreKey; label: string; tagHi: string; tagEn: string }[] = [
  { key: 'apocalypse', label: 'Apocalypse', tagHi: HI.apocalypse.tag, tagEn: EN.apocalypse.tag },
  { key: 'system', label: 'Leveling', tagHi: HI.system.tag, tagEn: EN.system.tag },
  { key: 'regression', label: 'Regression', tagHi: HI.regression.tag, tagEn: EN.regression.tag },
  { key: 'fantasy', label: 'Fantasy / Murim', tagHi: HI.fantasy.tag, tagEn: EN.fantasy.tag },
  { key: 'horror', label: 'Horror', tagHi: HI.horror.tag, tagEn: EN.horror.tag },
  { key: 'romance', label: 'Romance', tagHi: HI.romance.tag, tagEn: EN.romance.tag },
  { key: 'action', label: 'Action', tagHi: HI.action.tag, tagEn: EN.action.tag },
  { key: 'scifi', label: 'Sci-Fi', tagHi: HI.scifi.tag, tagEn: EN.scifi.tag },
];

// ── shared genre asset accessor (visual banks + sound recipes) ──

export function genreAssets(genre: GenreKey, lang: Lang = 'hinglish') {
  const g = (lang === 'hinglish' ? HI : EN)[genre];
  return { tag: g.tag, visuals: g.visuals, sounds: g.sounds };
}

// ── the generator ────────────────────────────────────────────

let packId = 0;

export function generatePack(inp: ScriptInput, seed = 0): ScriptPack {
  const g = (inp.lang === 'hinglish' ? HI : EN)[inp.genre];
  const budget = Math.round(inp.duration * 2.6);

  const sents = splitSentences(inp.scene || g.defaultScene);
  const s0 = sents[0] ?? '';
  const rest = [...sents.slice(1)];

  const buildTurn = () => {
    let t = pick(g.turn, seed);
    if (rest.length) t += ' ' + rest.join(' ');
    if (g.systemLine && g.sysIntro) {
      t += ' ' + pick(g.sysIntro, seed) + ' "' + rep(g.systemLine, inp) + '"';
    }
    return t;
  };

  let turn = buildTurn();
  let wordsFor = (paras: string[]) => countWords(paras.join(' '));

  const paras = [
    rep(pick(g.hook, seed), inp),
    (pick(g.setup, seed) + ' ' + s0).trim(),
    null as unknown as string, // turn placeholder
    (pick(g.escalate, seed) + ' ' + pick(g.realize, seed)).trim(),
    pick(g.resolve, seed),
    rep(pick(g.cta, seed + (inp.tone === 'dramatic' ? 1 : 0)), inp),
  ];

  paras[2] = turn;
  // budget trim: drop trailing scene sentences if we overshoot hard
  while (rest.length > 0 && wordsFor(paras) > budget * 1.12) {
    rest.pop();
    paras[2] = buildTurn();
  }
  // filler if undershooting
  if (wordsFor(paras) < budget * 0.66) paras[3] += ' ' + pick(g.filler, seed);

  const words = wordsFor(paras);
  const estMin = Math.round(words / 2.9);
  const estMax = Math.round(words / 2.45);

  // scene table — one row per paragraph, timing ∝ word share
  const counts = paras.map(countWords);
  const total = counts.reduce((a, b) => a + b, 0);
  let acc = 0;
  const scenes: SceneRow[] = paras.map((p, i) => {
    const from = Math.round((acc / total) * inp.duration);
    acc += counts[i];
    const to = i === paras.length - 1 ? inp.duration : Math.round((acc / total) * inp.duration);
    const v = g.visuals[i % g.visuals.length];
    return {
      from,
      to,
      line: excerpt(p),
      visual: rep(v.visual, inp),
      fx: v.fx,
    };
  });

  return {
    id: ++packId,
    input: inp,
    genreTag: inp.lang === 'hinglish' ? g.tag : EN[inp.genre].tag,
    coldOpen: {
      title: rep(g.cold, inp),
      reasons: [...g.reasons],
      summary: `Scene: ${inp.scene || g.defaultScene}`,
    },
    narration: { paragraphs: paras, words, estMin, estMax },
    scenes,
    sound: [...g.sounds],
    road: [
      {
        part: inp.part,
        title: excerpt(s0 || inp.scene || g.defaultScene, 6).replace(' …', ''),
        desc: inp.lang === 'hinglish' ? 'Cold open + trigger moment (upar wala script).' : 'Cold open + trigger moment (the script above).',
      },
      ...g.road.map((r, i) => ({ part: inp.part + 1 + i, title: r.title, desc: r.desc })),
    ],
    rule: g.rule,
  };
}

// ── full-pack → copyable text ────────────────────────────────

export function packToText(p: ScriptPack): string {
  const L: string[] = [];
  L.push(`SHORT SCRIPT PACK — ${p.input.title.toUpperCase()}`);
  L.push(`Genre: ${p.input.genre} | Part ${p.input.part} | ~${p.input.duration}s | ${p.narration.words} words (est ${p.narration.estMin}-${p.narration.estMax}s VO)`);
  L.push('');
  L.push('[1] KAHAAN SE SHURU KARNA HAI — COLD OPEN');
  L.push(p.coldOpen.title);
  p.coldOpen.reasons.forEach((r) => L.push('  - ' + r));
  L.push(p.coldOpen.summary);
  L.push('');
  L.push('[2] READY SCRIPT — POV VOICEOVER');
  p.narration.paragraphs.forEach((t) => { L.push(t); L.push(''); });
  L.push('[3] SCENE-BY-SCENE EDITING');
  p.scenes.forEach((s) => L.push(`  ${s.from}-${s.to}s | "${s.line}" | ${s.visual} | FX: ${s.fx.join(', ')}`));
  L.push('');
  L.push('[4] SOUND DESIGN');
  p.sound.forEach((s) => L.push(`  - ${s.label}: ${s.desc}`));
  L.push('');
  L.push('[5] SERIES ROADMAP');
  p.road.forEach((r) => L.push(`  Part ${r.part}: ${r.title} — ${r.desc}`));
  L.push('Rule: ' + p.rule);
  return L.join('\n');
}
