// ─────────────────────────────────────────────────────────────
//  SERIES ENGINE — title name in → full arc-wise MC-POV
//  Hinglish narration out (Part 1..N, 45s/60s each)
// ─────────────────────────────────────────────────────────────
import type { GenreKey, SceneRow, SoundNote } from './generator';
import { countWords, genreAssets } from './generator';

export type MediaType = 'MANHWA' | 'ANIME' | 'DONGHUA' | 'MANGA' | 'NOVEL' | 'CUSTOM';
export type PersonaKey = 'underdog' | 'cunning' | 'cold' | 'wild' | 'noble';

export interface ArcSrc {
  a: string;      // arc/part title
  h: string;      // hook (MC voice)
  e: string[];    // events, 1-3 sentences each slot
  t: string;      // the turn — punchline
  x: string;      // exit beat — cliffhangery close
}

export interface TitleSrc {
  id: string;
  name: string;
  aka?: string[];
  type: MediaType;
  genre: GenreKey;
  mc: string;
  persona: PersonaKey;
  status: 'ongoing' | 'complete' | 'custom';
  why: string; // why part 1 cold-open works
  plot?: string; // for custom titles
  parts: ArcSrc[];
}

export interface PartScript {
  n: number; // 1-based part number
  arc: string;
  hookWhy: string;
  paragraphs: string[];
  words: number;
  estMin: number;
  estMax: number;
  scenes: SceneRow[];
  sound: SoundNote[];
  nextTease: string | null;
}

export interface SeriesPack {
  title: TitleSrc;
  duration: number;
  parts: PartScript[];
}

// ── persona banks: connective lines + CTA style per MC archetype ──

interface Persona {
  label: string;
  reflect: string[]; // filler reflective lines (MC monologue)
  cta: (next: string, n: number) => string;
  end: string; // final part outro
}

const PERSONAS: Record<PersonaKey, Persona> = {
  underdog: {
    label: 'Underdog (zero se hero)',
    reflect: [
      'Ab peeche mudke dekhta hoon to lagta hai — zindagi ne mujhe pehle hi bata diya tha. Main sunna nahi chaahta tha.',
      'Sach kahun? Darr laga tha. Par peeche hatna... woh maine kabhi seekha hi nahi.',
      'Log hans te the. Aaj wohi log mera naam gungunaate hain — bas tab tak main ruka nahi.',
      'Har raat ek hi sawaal tha — "kyun main?" Aur har subah ek hi jawab — "kyun nahi main?"',
    ],
    cta: (next, n) => `Part ${n} mein — ${next}. Follow karke rehna, kyunki yeh kahani abhi seedhi nahi hui hai.`,
    end: 'Series yahin complete — par asli level-up tumhari apni story hai. Agli kahani pe milte hain. Follow kar liya na? Achha.',
  },
  cunning: {
    label: 'Cunning (dimaag se khelne wala)',
    reflect: [
      'Sab apni taakat pe bharosa karte the. Main? Main sirf information pe.',
      'Jhooth bolna bura hai — kehte hain. Par jab jhooth hi sach ko jeetta hai, to jhooth hi sach ban jaata hai.',
      'Har move pehle se sochi thi. Kam se kam... main yahi sochna chahta tha.',
      'Duniya ko lagta tha wo board dekh rahi hai. Asal mein main keede-makodon ki tarah chhupke chal raha tha — ek-ek square.',
    ],
    cta: (next, n) => `Part ${n} mein — ${next}. Follow kar lo... mujhe to pehle se pata hai kya hone wala hai. Tumhe nahi.`,
    end: 'Kahani khatam. Par ek baat yaad rakhna — jo sabse zyada jaanta hai, use sabse zyada bhav nahi milta. Bas kahaniyan milti hain. Agli series pe milte hain.',
  },
  cold: {
    label: 'Cold (badla / shaant khatra)',
    reflect: [
      'Andhere mein rona seekh liya tha maine — bina awaaz ke. Ab kisi ko awaaz sunayi nahi deti.',
      'Dayaa? Woh shabd maine bahut pehle ghar ke bahar chhod diya tha.',
      'Log nafrat se darte hain. Main nafrat nahi karta — main sirf hisaab barabar karta hoon.',
      'Har chehre yaad hai. Har naam. Ek-ek karke, sabka number aayega.',
    ],
    cta: (next, n) => `Part ${n} — ${next}. Kehna zaroori nahi... par follow kar lena. Badla abhi aur thanda hoga.`,
    end: 'Hisaab barabar ho gaya. Khamoshi... acchi lagti hai. Agli kahani mein phir milenge — tab tak sambhal ke rehna.',
  },
  wild: {
    label: 'Wild (bekabu, dil ke seedhe)',
    reflect: [
      'Log kehte the dimaag se khel. Arre bhai, jab dil hi itna zor se dhadakta hai, to dimaag ko waqt hi kahan milta hai?',
      'Rona, hasna, ladna — sab full volume pe. Aadhi zindagi mujhse nahi jeeti jaati.',
      'Plan? Mere paas plan nahi tha. Mere paas reason tha — aur reason ke saamne plan haar jaata hai.',
      'Mujhe fark nahi padta duniya kya sochti hai. Mujhe fark padta hai — mere log safe hain ya nahi.',
    ],
    cta: (next, n) => `Part ${n} mein — ${next}! Miss mat karna warna bahut regret hoga. Follow maar do, jaldi karo.`,
    end: 'Aur bas! Kahani ka yeh safar yahin khatam — par hasna band mat karna. Agli series pe phir shor machayenge. FOLLOW!',
  },
  noble: {
    label: 'Noble (apno ke liye ladne wala)',
    reflect: [
      'Taqat ka matlab kabhi kisi ko girana nahi tha. Taqat ka matlab tha — girte hue ko sambhalna.',
      'Mere peeche jo log khade the, unki aankhon mein dekh ke jawaab mil gaya tha — main haar nahi sakta.',
      'Darr sabko lagta hai. Hero woh nahi jo darta nahi — hero woh jo dar ke baawajood aage badhta hai.',
      'Ek waqt tha jab main akela tha. Ab? Ab mere kandhon pe vishwaas hai — aur woh sabse bhaari hota hai.',
    ],
    cta: (next, n) => `Part ${n} mein — ${next}. Saath chaloge? Follow karke rakhna — apno ka saath sabse badi taqat hai.`,
    end: 'Kahani poori hui — par apno ki kahani kabhi khatam nahi hoti. Apna khayal rakhna. Agli series mein phir saath chalenge.',
  },
};

const GENRE_PERSONA: Record<GenreKey, PersonaKey> = {
  apocalypse: 'cunning',
  system: 'underdog',
  regression: 'cold',
  fantasy: 'noble',
  horror: 'cold',
  romance: 'noble',
  action: 'wild',
  scifi: 'cunning',
};

const HOOK_WHY_NEXT = [
  'Cliffhanger payoff — pichhle part ka promise yahan deliver hota hai. Retention spike.',
  'Mid-series hook — stakes double, kam explanation, zyada raftar.',
  'Arc shift — naya direction, naye faces; scroll-away audience wapas pakadti hai.',
  'Emotional peak — comments aur shares isi part se aate hain.',
  'Finale charge — poori series ka payoff; rewatch trigger.',
];

// ── assembly ─────────────────────────────────────────────────

function excerpt(t: string, n = 9): string {
  const w = t.trim().split(/\s+/);
  return w.length > n ? w.slice(0, n).join(' ') + ' …' : t;
}

function buildPart(title: TitleSrc, i: number, duration: number): PartScript {
  const arc = title.parts[i];
  const next = title.parts[i + 1];
  const P = PERSONAS[title.persona];
  const budget = Math.round(duration * 2.6);

  const paras: string[] = [];
  paras.push(arc.h);
  const eventsA = arc.e.slice(0, 2).join(' ');
  const eventsB = arc.e.length > 2 ? arc.e.slice(2).join(' ') : '';
  paras.push(eventsA);
  if (eventsB) paras.push(eventsB);
  paras.push(arc.t);
  paras.push(arc.x);
  paras.push(next ? P.cta(next.a, i + 2) : P.end);

  let words = countWords(paras.join(' '));
  if (words < budget * 0.68) {
    paras.splice(paras.length - 2, 0, P.reflect[(i * 2) % P.reflect.length]);
    words = countWords(paras.join(' '));
  }

  const assets = genreAssets(title.genre, 'hinglish');
  const counts = paras.map(countWords);
  const total = counts.reduce((a, b) => a + b, 0);
  let acc = 0;
  const scenes: SceneRow[] = paras.map((p, k) => {
    const from = Math.round((acc / total) * duration);
    acc += counts[k];
    const to = k === paras.length - 1 ? duration : Math.round((acc / total) * duration);
    const v = assets.visuals[(k + i) % assets.visuals.length];
    return { from, to, line: excerpt(p), visual: v.visual, fx: v.fx };
  });

  return {
    n: i + 1,
    arc: arc.a,
    hookWhy:
      i === 0
        ? title.why
        : HOOK_WHY_NEXT[i % HOOK_WHY_NEXT.length] + (next ? ` · Next seed: "${next.a}"` : ' · Series end — full payoff.'),
    paragraphs: paras,
    words,
    estMin: Math.round(words / 2.9),
    estMax: Math.round(words / 2.45),
    scenes,
    sound: assets.sounds.map((s) => ({ ...s })),
    nextTease: next ? next.a : null,
  };
}

export function buildSeries(title: TitleSrc, duration: number): SeriesPack {
  return {
    title,
    duration,
    parts: title.parts.map((_, i) => buildPart(title, i, duration)),
  };
}

// ── custom title: plot dump → auto parts ─────────────────────

export function splitPlot(plot: string, maxParts = 8): ArcSrc[] {
  const sents = plot
    .split(/(?<=[.!?…।])\s+/)
    .map((s) => s.trim())
    .filter((s) => countWords(s) > 2);
  if (sents.length === 0) return [];
  const nParts = Math.max(3, Math.min(maxParts, Math.round(sents.length / 2.6)));
  const per = Math.ceil(sents.length / nParts);
  const arcs: ArcSrc[] = [];
  const turns = [
    'Aur tabhi — sab kuch badal gaya.',
    'Par wahi hua jiska maine kabhi andaaza nahi kiya tha.',
    'Us pal mujhe samajh aa gaya — yeh sirf shuruaat thi.',
    'Lekin asli imtihaan to abhi baaki tha.',
  ];
  for (let i = 0; i < nParts; i++) {
    const chunk = sents.slice(i * per, (i + 1) * per);
    if (!chunk.length) break;
    const title = i === 0 ? 'Shuruaat' : excerpt(chunk[0], 5).replace(' …', '');
    arcs.push({
      a: title.charAt(0).toUpperCase() + title.slice(1),
      h: chunk[0],
      e: chunk.slice(1, 3).length ? chunk.slice(1, 3) : ['Sab kuch tezi se badal raha tha. Rukne ka naam hi nahi le raha tha.'],
      t: turns[i % turns.length],
      x: chunk[chunk.length - 1] === chunk[0] ? 'Aur main jaanta tha — ab peeche mudna mumkin nahi.' : chunk[chunk.length - 1],
    });
  }
  return arcs;
}

export function buildCustomTitle(cfg: {
  uid: string;
  name: string;
  type: MediaType;
  genre: GenreKey;
  mc: string;
  plot: string;
}): TitleSrc {
  return {
    id: 'custom_' + cfg.uid,
    name: cfg.name,
    type: cfg.type === 'CUSTOM' ? 'NOVEL' : cfg.type,
    genre: cfg.genre,
    mc: cfg.mc.trim() || 'Main Character',
    persona: GENRE_PERSONA[cfg.genre],
    status: 'custom',
    why: 'Custom premise — tumne jo scene diya wahi cold-open ka base hai. Pehla part hook pe focus karta hai, baaki parts tension build karte hain.',
    plot: cfg.plot,
    parts: splitPlot(cfg.plot),
  };
}

export function customFromSerialized(s: {
  uid: string; name: string; type: MediaType; genre: GenreKey; mc: string; plot: string;
}): TitleSrc {
  return buildCustomTitle(s);
}

// ── copyable text exports ────────────────────────────────────

export function partToText(title: TitleSrc, p: PartScript): string {
  const L: string[] = [];
  L.push(`${title.name.toUpperCase()} — PART ${p.n}/${title.parts.length} · "${p.arc}"`);
  L.push(`MC-POV narration · ~${p.words} words (est ${p.estMin}-${p.estMax}s)`);
  L.push('');
  p.paragraphs.forEach((t) => { L.push(t); L.push(''); });
  L.push('EDIT BEATS:');
  p.scenes.forEach((s) => L.push(`  ${s.from}-${s.to}s | "${s.line}" | ${s.visual} | FX: ${s.fx.join(', ')}`));
  L.push('');
  L.push('SOUND:');
  p.sound.forEach((s) => L.push(`  - ${s.label}: ${s.desc}`));
  return L.join('\n');
}

export function seriesToText(pack: SeriesPack): string {
  const head = [
    `FULL SERIES SCRIPT — ${pack.title.name.toUpperCase()} (${pack.title.type})`,
    `MC: ${pack.title.mc} · Parts: ${pack.parts.length} · Duration per part: ~${pack.duration}s · Voice: Hinglish MC-POV`,
    '='.repeat(64),
    '',
  ];
  return head.concat(pack.parts.map((p) => partToText(pack.title, p)).join('\n' + '-'.repeat(64) + '\n\n')).join('\n');
}

export const PERSONA_LABEL = (k: PersonaKey) => PERSONAS[k].label;
